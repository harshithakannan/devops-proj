const express = require("express");
const mongoose = require("mongoose");
const dotenv =  require("dotenv");
const cors = require("cors");

dotenv.config();

const app = express();
app.use(express.json());
//app.use(cors({origin:"https://dress-shop-1-o8sp.onrender.com"}));
app.use(cors());
app.use(express.urlencoded({ extended: true }));

const authRoutes = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");
const ReportRoutes=require("./routes/ReportRoutes");
const admindashboardRoutes = require("./routes/admindashboardRoutes");



const connectDB = require("./config/db");
app.use("/api/auth",authRoutes);
app.use("/api/product",productRoutes);
app.use("/uploads", express.static("uploads"));
app.use('/api/reports', ReportRoutes);
app.use('/api/admindashboard',admindashboardRoutes);


connectDB();
const port = process.env.PORT;
app.listen(port,()=>console.log(`server is running on the port ${port}`))