const mongoose = require("mongoose");

const ColorSchema = new mongoose.Schema({
    color: { type: String, required: true },
    image: { type: String }, // Removed required: true to make optional
    stock: { 
        type: Number, 
        required: true, 
        min: 0,
        validate: {
            validator: Number.isInteger,
            message: 'Stock must be an integer value'
        }
    }
}, { _id: false }); // Added _id: false to prevent automatic ID generation

const SizeSchema = new mongoose.Schema({
    size: { 
        type: String, 
        required: true,
        trim: true // Automatically removes whitespace
    },
    price: { 
        type: Number, 
        required: true, 
        min: 0,
        set: v => parseFloat(v.toFixed(2)) // Ensures 2 decimal places
    },
    DiscountedPrice: { type: Number, default: 0 },
    colors: {
        type: [ColorSchema],
        validate: {
            validator: function(v) {
                return v.length > 0;
            },
            message: 'At least one color is required'
        }
    }
}, { _id: false });

const ProductSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true,
        trim: true,
        maxlength: 100 
    },
    material: { 
        type: String, 
        required: true,
        trim: true,
        maxlength: 50 
    },
    category: { 
        type: String, 
        enum: ["Men", "Women", "Kids"], 
        required: true,
        index: true // Added index for better query performance
    },
    images: { 
        type: [String], 
        validate: {
            validator: function(v) {
                return v.length >= 1 && v.length <= 4;
            },
            message: 'Must have between 1 and 4 images'
        },
        required: true 
    },
    sizes: { 
        type: [SizeSchema], 
        required: true,
        validate: {
            validator: function(v) {
                return v.length > 0;
            },
            message: 'At least one size is required'
        }
    },
    description: { 
        type: String, 
        required: true,
        trim: true,
        maxlength: 1000 
    },
    sizeChartImage: { 
        type: String,
        default: null // Explicit default
    },
    discount: { 
        type: Number,
        min: 0,
        max: 100,
        default: 0
      },
      discountEndDate: {
        type: Date,
        default: null
      },
}, { 
    timestamps: true,
    toJSON: { virtuals: true }, // Include virtuals when converting to JSON
    toObject: { virtuals: true } 
});

// Add text index for search functionality
ProductSchema.index({
    name: 'text',
    material: 'text',
    description: 'text'
});

// Virtual for getting the first image (useful for thumbnails)
ProductSchema.virtual('mainImage').get(function() {
    return this.images[0];
});

const Product = mongoose.model("Product", ProductSchema);
module.exports = Product;