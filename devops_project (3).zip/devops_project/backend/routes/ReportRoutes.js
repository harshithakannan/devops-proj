// routes/reportRoutes.js
const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');

router.get('/stock/:type', (req, res) => {
  const { type } = req.params;
  
  if (type === 'pdf') {
    return reportController.generateStockPDF(res);
  } else if (type === 'excel') {
    return reportController.generateStockExcel(res);
  }
  
  return res.status(400).json({ message: 'Invalid report type' });
});

module.exports = router;