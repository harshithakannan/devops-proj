const express = require("express");
const router = express.Router();
const { upload } = require("../middlewares/uploads");
const { addProduct, viewProduct, deleteProduct, getProductById, 
    updateProduct} = require("../controllers/productController");

// Define the Multer middleware for product images
const productUpload = upload.fields([
    { name: "productImages", maxCount: 4 }, 
    { name: "colorImages", maxCount: 10 },// 4 product images 
    { name: 'sizeChartImage', maxCount: 1 }
]);

const updateProductImageUpload = upload.fields([
    { name: 'newProductImages', maxCount: 4 },
    { name: 'newColorImages', maxCount: 20 },
    { name: 'sizeChartImage', maxCount: 1 }
]);

// Route for adding a product with file upload
router.post("/add-product", productUpload, addProduct);
router.get("/display_products", viewProduct);
router.delete("/delete/:productId", deleteProduct);
router.get('/:productId', getProductById);
router.put('/update-product', updateProductImageUpload, updateProduct);

module.exports = router;
