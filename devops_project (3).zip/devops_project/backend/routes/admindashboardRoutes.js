const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/admindashboardController');

// GET total product count
router.get('/count', dashboardController.getProductCount);

// GET all categories
router.get('/categories', dashboardController.getAllCategories);

// GET low stock products
router.get('/low-stock', dashboardController.getLowStockProducts);

module.exports = router;