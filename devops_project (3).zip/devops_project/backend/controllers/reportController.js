// controllers/reportController.js
const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const Product = require('../models/Product');

// Generate PDF Report
const generateStockPDF = async (res) => {
  try {
    const products = await Product.find().lean();
    
    // Create PDF document
    const doc = new PDFDocument();
    const filename = `stock-report-${new Date().toISOString().split('T')[0]}.pdf`;
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    // Pipe PDF to response
    doc.pipe(res);
    
    // Add title
    doc.fontSize(20).text('Stock Status Report', { align: 'center' });
    doc.moveDown();
    
    // Add date
    doc.fontSize(12).text(`Generated on: ${new Date().toLocaleString()}`, { align: 'center' });
    doc.moveDown(2);
    
    // Add product table
    let yPosition = 150;
    const startX = 50;
    const rowHeight = 30;
    const colWidths = [200, 100, 100, 100];
    
    // Table headers
    doc.font('Helvetica-Bold')
       .fontSize(12)
       .text('Product Name', startX, yPosition)
       .text('Size', startX + colWidths[0], yPosition)
       .text('Color', startX + colWidths[0] + colWidths[1], yPosition)
       .text('Stock', startX + colWidths[0] + colWidths[1] + colWidths[2], yPosition, { align: 'right' });
    
    yPosition += rowHeight;
    doc.font('Helvetica');
    
    // Table rows
    products.forEach(product => {
      product.sizes.forEach(size => {
        size.colors.forEach(color => {
          doc.fontSize(10)
             .text(product.name, startX, yPosition)
             .text(size.size, startX + colWidths[0], yPosition)
             .text(color.color, startX + colWidths[0] + colWidths[1], yPosition)
             .text(color.stock.toString(), startX + colWidths[0] + colWidths[1] + colWidths[2], yPosition, { align: 'right' });
          
          yPosition += rowHeight;
          
          // Add new page if needed
          if (yPosition > 700) {
            doc.addPage();
            yPosition = 50;
          }
        });
      });
    });
    
    // Finalize PDF
    doc.end();
  } catch (error) {
    console.error('Error generating PDF:', error);
    res.status(500).json({ message: 'Error generating report' });
  }
};

// Generate Excel Report
const generateStockExcel = async (res) => {
  try {
    const products = await Product.find().lean();
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Stock Report');
    
    // Add headers
    worksheet.columns = [
      { header: 'Product Name', key: 'name', width: 30 },
      { header: 'Size', key: 'size', width: 15 },
      { header: 'Color', key: 'color', width: 15 },
      { header: 'Stock', key: 'stock', width: 15 }
    ];
    
    // Add data
    products.forEach(product => {
      product.sizes.forEach(size => {
        size.colors.forEach(color => {
          worksheet.addRow({
            name: product.name,
            size: size.size,
            color: color.color,
            stock: color.stock
          });
        });
      });
    });
    
    // Style headers
    worksheet.getRow(1).eachCell(cell => {
      cell.font = { bold: true };
    });
    
    // Set response headers
    const filename = `stock-report-${new Date().toISOString().split('T')[0]}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    // Write to response
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Error generating Excel:', error);
    res.status(500).json({ message: 'Error generating report' });
  }
};

module.exports = {
  generateStockPDF,
  generateStockExcel
};