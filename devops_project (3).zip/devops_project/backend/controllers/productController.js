const Product = require("../models/Product"); // Make sure this import exists
const fs = require('fs'); 
const path = require('path');


const addProduct = async (req, res) => {
    try {
        const { name, material, category, description, discount = 0, discountEndDate } = req.body;
        
        console.log(req.body);
        // Validate required fields first
        if (!name || !material || !category || !req.body.sizes || !description) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const parsedSizes = JSON.parse(req.body.sizes);
        const parsedColorIndexes = req.body.colorIndexes ? JSON.parse(req.body.colorIndexes) : [];
        const discountValue = parseInt(discount) || 0;
        const isValidDiscount = discountValue >= 0 && discountValue <= 100;
        const hasDiscount = isValidDiscount && discountValue > 0;

        // Validate discount end date if discount is applied
        if (hasDiscount && !discountEndDate) {
            return res.status(400).json({ 
                message: "Discount end date is required when applying a discount" 
            });
        }

        // Validate product images (1-4)
        const productImages = req.files["productImages"] || [];
        if (productImages.length < 1 || productImages.length > 4) {
            // Cleanup uploaded files
            cleanupFiles(req.files);
            return res.status(400).json({ 
                message: "You must upload between 1 and 4 product images" 
            });
        }

        const imagePaths = productImages.map(file => `uploads/${file.filename}`);
        const sizeChartImage = req.files['sizeChartImage']?.[0] 
            ? `uploads/${req.files['sizeChartImage'][0].filename}`
            : null;

        // Process sizes and colors with validation
        const updatedSizes = parsedSizes.map(size => {
            const originalPrice = parseFloat(size.Price) || 0;
            let price = originalPrice;
            let Discountamount=0;
            // Calculate discounted price if valid discount exists
            if (hasDiscount) {
                 Discountedprice = Math.round(originalPrice * (1 - discountValue / 100));
            console.log(Discountedprice+" "+price);   
                 Discountamount = Discountedprice; 
                // Validate that original price is greater than discounted price
                if (originalPrice <= Discountedprice) {
                    throw new Error(
                        `Original price (${originalPrice}) must be greater than ` +
                        `discounted price (${Discountedprice}) for size ${size.size}`
                    );
                }
            }

            // Validate that we have at least one color for each size
            if (!size.colors || size.colors.length === 0) {
                throw new Error(`At least one color is required for size ${size.size}`);
            }
            console.log(Discountamount);
            return {
                size: size.size,
                price:originalPrice, // Store original price
                DiscountedPrice: Discountamount, // This will be the discounted price if discount exists
                colors: size.colors.map(color => ({
                    color: color.color,
                    stock: parseInt(color.stock) || 0,
                    image: null // Will be populated later if images exist
                }))
            };
        });
  
        // Assign color images if provided
        if (req.files["colorImages"] && parsedColorIndexes.length > 0) {
            const colorImages = Array.isArray(req.files["colorImages"])
                ? req.files["colorImages"]
                : [req.files["colorImages"]];

            parsedColorIndexes.forEach(({ sizeIndex, colorIndex }, i) => {
                if (updatedSizes[sizeIndex]?.colors[colorIndex] && colorImages[i]) {
                    updatedSizes[sizeIndex].colors[colorIndex].image = 
                        `uploads/${colorImages[i].filename}`;
                }
            });
        }

        // Create product
        const newProduct = new Product({
            name,
            material,
            category,
            images: imagePaths,
            sizes: updatedSizes,
            description,
            sizeChartImage,
            discount: hasDiscount ? discountValue : 0,
            discountEndDate: hasDiscount ? new Date(discountEndDate) : null
        });

        await newProduct.save();
        
        res.status(201).json({ 
            message: "Product added successfully!", 
            product: newProduct 
        });

    } catch (error) {
        console.error("Error adding product:", error);
        
        // Cleanup uploaded files on error
        if (req.files) {
            cleanupFiles(req.files);
        }
        
        const errorMessage = error.message.startsWith("Original price") || 
                           error.message.startsWith("At least one color") 
                           ? error.message 
                           : "Error adding product";
        
        res.status(400).json({ 
            message: errorMessage,
            error: error.message 
        });
    }
};

// Helper function to cleanup uploaded files
function cleanupFiles(files) {
    Object.values(files).flat().forEach(file => {
        if (file.path && fs.existsSync(file.path)) {
            try {
                fs.unlinkSync(file.path);
            } catch (err) {
                console.error("Error deleting file:", file.path, err);
            }
        }
    });
};

const viewProduct = async(req,res) =>{
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (error) {
        console.error("Error fetching products:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
}


// DELETE PRODUCT FUNCTION
const deleteProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }

        // Delete associated images from server
        product.images.forEach((image) => {
            const imagePath = `./${image}`;
            if (fs.existsSync(imagePath)) {
                fs.unlinkSync(imagePath);
            }
        });

        product.sizes.forEach((size) => {
            size.colors.forEach((color) => {
                if (color.image) {
                    const colorImagePath = `./${color.image}`;
                    if (fs.existsSync(colorImagePath)) {
                        fs.unlinkSync(colorImagePath);
                    }
                }
            });
        });

        await Product.findByIdAndDelete(productId);

        res.status(200).json({ message: "Product deleted successfully" });
    } catch (error) {
        console.error("Error deleting product:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

const getProductById = async (req, res) => {
    try {
        const { productId } = req.params;
        const product = await Product.findById(productId);
        
        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }
        
        res.status(200).json(product);
    } catch (error) {
        console.error("Error fetching product:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};


const updateProduct = async (req, res) => {
    try {
        const { productId, name, material, category, description, removeSizeChart, discount, discountEndDate } = req.body;
        console.log("Updating product:", productId);
        console.log("Received files:", req.files);
        console.log("Received body:", req.body);

        // Find the product
        const product = await Product.findById(productId);
        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }

        // Handle size chart image
        let sizeChartImage = product.sizeChartImage;
        if (req.files && req.files['sizeChartImage']) {
            // Delete old image if exists
            if (product.sizeChartImage) {
                const oldPath = path.join(__dirname, '..', product.sizeChartImage);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                    console.log(`Deleted old size chart: ${product.sizeChartImage}`);
                }
            }
            sizeChartImage = `uploads/${req.files['sizeChartImage'][0].filename}`;
        } else if (removeSizeChart === 'true') {
            // Handle explicit removal of size chart
            if (product.sizeChartImage) {
                const oldPath = path.join(__dirname, '..', product.sizeChartImage);
                if (fs.existsSync(oldPath)) {
                    fs.unlinkSync(oldPath);
                    console.log(`Deleted size chart as requested: ${product.sizeChartImage}`);
                }
            }
            sizeChartImage = undefined;
        }

        // Parse JSON data from body
        const sizes = req.body.sizes ? JSON.parse(req.body.sizes) : [];
        const existingImages = req.body.existingImages ? JSON.parse(req.body.existingImages) : [];
        const existingColorImages = req.body.existingColorImages ? JSON.parse(req.body.existingColorImages) : [];
        const newColorIndexes = req.body.newColorIndexes ? JSON.parse(req.body.newColorIndexes) : [];

        // Validate required fields
        if (!name || !material || !category || !sizes.length || !description) {
            return res.status(400).json({ message: "All fields are required" });
        }

        // Handle product images
        let updatedImages = [...existingImages];
        
        // Add new product images if any
        if (req.files && req.files["newProductImages"]) {
            const newProductImages = Array.isArray(req.files["newProductImages"]) 
                ? req.files["newProductImages"] 
                : [req.files["newProductImages"]];
                
            newProductImages.forEach(file => {
                updatedImages.push(`uploads/${file.filename}`);
            });
        }

        // Create a deep copy of sizes for updating
        const updatedSizes = JSON.parse(JSON.stringify(sizes));
        
        // Map existing color images to their respective colors
        existingColorImages.forEach(imgData => {
            const { path: imagePath, sizeIndex, colorIndex } = imgData;
            
            if (
                updatedSizes[sizeIndex] && 
                updatedSizes[sizeIndex].colors[colorIndex]
            ) {
                updatedSizes[sizeIndex].colors[colorIndex].image = imagePath;
            }
        });

        // Add new color images
        if (req.files && req.files["newColorImages"] && newColorIndexes.length > 0) {
            const newColorImages = Array.isArray(req.files["newColorImages"]) 
                ? req.files["newColorImages"] 
                : [req.files["newColorImages"]];
                
            for (let i = 0; i < newColorImages.length; i++) {
                if (i < newColorIndexes.length) {
                    const { sizeIndex, colorIndex } = newColorIndexes[i];
                    
                    if (
                        updatedSizes[sizeIndex] && 
                        updatedSizes[sizeIndex].colors[colorIndex]
                    ) {
                        updatedSizes[sizeIndex].colors[colorIndex].image = 
                            `uploads/${newColorImages[i].filename}`;
                    }
                }
            }
        }

        // Find images to delete (those in product.images but not in existingImages)
        const imagesToDelete = product.images.filter(img => !existingImages.includes(img));
        
        // Find color images to delete
        const colorImagesToDelete = [];
        product.sizes.forEach((size, sizeIndex) => {
            size.colors.forEach((color, colorIndex) => {
                if (color.image) {
                    // Check if this image is in the existingColorImages list
                    const exists = existingColorImages.some(img => 
                        img.path === color.image && 
                        img.sizeIndex === sizeIndex && 
                        img.colorIndex === colorIndex
                    );
                    
                    if (!exists) {
                        colorImagesToDelete.push(color.image);
                    }
                }
            });
        });

        // Delete unused images
        const deletePromises = [...imagesToDelete, ...colorImagesToDelete].map(imgPath => {
            return new Promise((resolve) => {
                const fullPath = path.join(__dirname, '..', imgPath);
                if (fs.existsSync(fullPath)) {
                    fs.unlink(fullPath, (err) => {
                        if (err) {
                            console.error(`Error deleting image ${imgPath}:`, err);
                        } else {
                            console.log(`Deleted unused image: ${imgPath}`);
                        }
                        resolve();
                    });
                } else {
                    resolve();
                }
            });
        });

        await Promise.all(deletePromises);

        // Handle discount values
        const discountValue = discount ? parseInt(discount) : 0;
        const discountEndDateValue = discountValue > 0 ? discountEndDate : null;

        // Prepare update data
        const updateData = {
            name,
            material,
            category,
            description,
            images: updatedImages,
            sizes: updatedSizes,
            discount: discountValue,
            discountEndDate: discountEndDateValue,
            ...(sizeChartImage !== undefined && { sizeChartImage }) // Only include if not undefined
        };

        // Update product in database
        const updatedProduct = await Product.findByIdAndUpdate(
            productId,
            updateData,
            { new: true }
        );

        res.status(200).json({ 
            message: "Product updated successfully", 
            product: updatedProduct 
        });

    } catch (error) {
        console.error("Error updating product:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};
module.exports = { 
    addProduct, 
    viewProduct, 
    deleteProduct, 
    getProductById, 
    updateProduct 
};

