const Product = require('../models/Product');

exports.getProductCount = async (req, res) => {
  try {
    const count = await Product.countDocuments();
    res.json({ count });
  } catch (error) {
    console.error('Error getting product count:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getAllCategories = async (req, res) => {
  try {
    const categories = await Product.distinct('category');
    res.json({ categories });
  } catch (error) {
    console.error('Error getting categories:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getLowStockProducts = async (req, res) => {
  try {
    const threshold = parseInt(req.query.threshold) || 20;
    
    const products = await Product.aggregate([
      { $unwind: "$sizes" },
      { $unwind: "$sizes.colors" },
      { 
        $match: { 
          $or: [
            { "sizes.stock": { $lt: threshold } },
            { "sizes.colors.stock": { $lt: threshold } }
          ]
        } 
      },
      {
        $project: {
          name: 1,
          category: 1,
          size: "$sizes.size",
          color: "$sizes.colors.color",
          stock: { 
            $cond: [
              { $lt: ["$sizes.stock", threshold] },
              "$sizes.stock",
              "$sizes.colors.stock"
            ]
          },
          mainImage: { $arrayElemAt: ["$images", 0] }
        }
      },
      { $limit: 20 }
    ]);
    
    res.json({ products });
  } catch (error) {
    console.error('Error getting low stock products:', error);
    res.status(500).json({ error: 'Server error' });
  }
};