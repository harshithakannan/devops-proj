import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../api";

const EditProduct = () => {
    const { productId } = useParams();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: "",
        material: "",
        images: [],
        category: "Men",
        sizes: [{ 
            size: "", 
            price: 0,
            DiscountedPrice: 0, 
            colors: [{ color: "", image: null, stock: 0 }] 
        }],
        description: "",
        sizeChartImage: null,
        discount: 0,
        discountEndDate: ""
    });
    const [existingImages, setExistingImages] = useState([]);
    const [imagesToDelete, setImagesToDelete] = useState([]);
    const [existingColorImages, setExistingColorImages] = useState([]);
    const [existingSizeChartImage, setExistingSizeChartImage] = useState(null);

    const BASE_URL = "http://localhost:5006/";

    // Fetch product data
    useEffect(() => {
        const fetchProduct = async () => {
            try {
                setLoading(true);
                  
                const response = await API.get(`/product/${productId}`);
                console.log(response.data);
                const product = response.data;
                
                // Format the data for the form
                setFormData({
                    name: product.name,
                    material: product.material,
                    category: product.category,
                    description: product.description,
                    discount: product.discount || 0,
                    discountEndDate: product.discountEndDate || "",
                    images: [], // We'll store new image files here
                    sizes: product.sizes.map(size => ({
                        size: size.size,
                        price: size.price, // Original price is stored as price
                        DiscountedPrice: size.DiscountedPrice || size.price, // Use DiscountedPrice if exists, otherwise fallback to price
                        colors: size.colors.map(color => ({
                            color: color.color,
                            image: null, // We'll store new color image files here
                            stock: color.stock
                        }))
                    })),
                    sizeChartImage: null
                });

                // Store existing size chart image
                if (product.sizeChartImage) {
                    setExistingSizeChartImage(product.sizeChartImage);
                }

                // Store existing image paths
                setExistingImages(product.images.map(img => ({
                    path: img,
                    isDeleted: false
                })));

                // Store existing color image paths
                const colorImgs = [];
                product.sizes.forEach((size, sizeIndex) => {
                    size.colors.forEach((color, colorIndex) => {
                        if (color.image) {
                            colorImgs.push({
                                path: color.image,
                                sizeIndex,
                                colorIndex,
                                isDeleted: false
                            });
                        }
                    });
                });
                setExistingColorImages(colorImgs);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching product:", error);
                alert("Error loading product data");
                setLoading(false);
            }
        };

        if (productId) {
            fetchProduct();
        }
    }, [productId]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Handle discount change and update prices
    const handleDiscountChange = (e) => {
        const discountValue = parseInt(e.target.value) || 0;
        const newDiscount = Math.min(100, Math.max(0, discountValue));
        
        setFormData(prev => {
            // Calculate new discounted prices for all sizes when discount changes
            const newSizes = prev.sizes.map(size => ({
                ...size,
                DiscountedPrice: newDiscount > 0 
                    ? Math.round(size.price * (1 - newDiscount/100))
                    : size.price
            }));
            
            return {
                ...prev,
                discount: newDiscount,
                sizes: newSizes,
                discountEndDate: newDiscount > 0 ? prev.discountEndDate : ""
            };
        });
    };

    // Handle discount end date change
    const handleDiscountEndDateChange = (e) => {
        setFormData(prev => ({
            ...prev,
            discountEndDate: e.target.value
        }));
    };

    // Handle price change for a size (original price)
    const handlePriceChange = (sizeIndex, value) => {
        const priceValue = parseFloat(value) || 0;
        
        setFormData(prev => {
            const newSizes = [...prev.sizes];
            newSizes[sizeIndex] = {
                ...newSizes[sizeIndex],
                price: priceValue,
                DiscountedPrice: prev.discount > 0 
                    ? Math.round(priceValue * (1 - prev.discount/100))
                    : priceValue
            };
            
            return { ...prev, sizes: newSizes };
        });
    };

    const handleImageUpload = (e) => {
        const files = Array.from(e.target.files);
        const remainingSlots = 4 - (existingImages.filter(img => !img.isDeleted).length + formData.images.length);
        
        if (files.length > remainingSlots) {
            alert(`You can only upload ${remainingSlots} more images.`);
            return;
        }
        
        setFormData((prevData) => ({
            ...prevData,
            images: [...prevData.images, ...files],
        }));
    };

    const handleSizeChartUpload = (e) => {
        if (e.target.files && e.target.files[0]) {
            setFormData(prev => ({
                ...prev,
                sizeChartImage: e.target.files[0]
            }));
        }
    };

    const handleRemoveSizeChart = () => {
        setFormData(prev => ({
            ...prev,
            sizeChartImage: null
        }));
        setExistingSizeChartImage(null);
    };

    const handleRemoveNewImage = (index) => {
        setFormData((prevData) => ({
            ...prevData,
            images: prevData.images.filter((_, i) => i !== index),
        }));
    };

    const handleRemoveExistingImage = (index) => {
        setExistingImages(prev => {
            const updated = [...prev];
            updated[index].isDeleted = true;
            return updated;
        });
    };

    const handleRestoreExistingImage = (index) => {
        setExistingImages(prev => {
            const updated = [...prev];
            updated[index].isDeleted = false;
            return updated;
        });
    };

    const handleAddSize = () => {
        setFormData((prev) => ({
            ...prev,
            sizes: [...prev.sizes, { 
                size: "", 
                price: 0,
                DiscountedPrice: 0, 
                colors: [{ color: "", image: null, stock: 0 }] 
            }]
        }));
    };

    const handleSizeChange = (index, field, value) => {
        const newSizes = [...formData.sizes];
        newSizes[index][field] = value;
        setFormData((prev) => ({ ...prev, sizes: newSizes }));
    };

    const handleAddColor = (sizeIndex) => {
        const newSizes = [...formData.sizes];
        newSizes[sizeIndex].colors.push({ color: "", image: null, stock: 0 });
        setFormData((prev) => ({ ...prev, sizes: newSizes }));
    };
    
    const handleColorChange = (sizeIndex, colorIndex, field, value) => {
        const newSizes = [...formData.sizes];
        if (field === "image") {
            // If updating an image, mark any existing image as deleted
            setExistingColorImages(prev => {
                return prev.map(img => {
                    if (img.sizeIndex === sizeIndex && img.colorIndex === colorIndex) {
                        return { ...img, isDeleted: true };
                    }
                    return img;
                });
            });
            
            if (value) {
                newSizes[sizeIndex].colors[colorIndex][field] = value;
            }
        } else {
            newSizes[sizeIndex].colors[colorIndex][field] = value;
        }
        setFormData((prev) => ({ ...prev, sizes: newSizes }));
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
    
        const productData = new FormData();
        productData.append("productId", productId);
        productData.append("name", formData.name);
        productData.append("material", formData.material);
        productData.append("category", formData.category);
        productData.append("description", formData.description);
        productData.append("discount", formData.discount);
        productData.append("discountEndDate", formData.discountEndDate);
    
        // Create a deep copy of sizes with modified structure for saving
        const sizesForSaving = formData.sizes.map(size => ({
            size: size.size,
            price: Number(size.price),
            DiscountedPrice: Number(size.DiscountedPrice),
            colors: size.colors.map(color => ({
                color: color.color,
                stock: Number(color.stock),
                image: null // We'll handle image paths on the server
            }))
        }));
        
        productData.append("sizes", JSON.stringify(sizesForSaving));
        
        // Handle existing images
        const keptImagePaths = existingImages
            .filter(img => !img.isDeleted)
            .map(img => img.path);
        productData.append("existingImages", JSON.stringify(keptImagePaths));
        
        // Append new product images
        formData.images.forEach((image) => {
            if (image instanceof File) {
                productData.append("newProductImages", image);
            }
        });
        
        // Handle existing color images
        const keptColorImages = existingColorImages
            .filter(img => !img.isDeleted)
            .map(img => ({
                path: img.path,
                sizeIndex: img.sizeIndex,
                colorIndex: img.colorIndex
            }));
        productData.append("existingColorImages", JSON.stringify(keptColorImages));

        // Handle size chart image
        if (formData.sizeChartImage) {
            productData.append("sizeChartImage", formData.sizeChartImage);
        } else if (existingSizeChartImage && !formData.sizeChartImage) {
            // If we're removing the existing size chart
            productData.append("removeSizeChart", "true");
        }
        
        // Collect all new color images indexes in an array
        const newColorIndexArray = [];
        
        // Append new color images
        formData.sizes.forEach((size, sizeIndex) => {
            size.colors.forEach((color, colorIndex) => {
                if (color.image && color.image instanceof File) {
                    productData.append("newColorImages", color.image);
                    newColorIndexArray.push({sizeIndex, colorIndex});
                }
            });
        });
        
        // Append the colorIndexes array as a single JSON string
        if (newColorIndexArray.length > 0) {
            productData.append("newColorIndexes", JSON.stringify(newColorIndexArray));
        }
    
        try {
            const res = await API.put("/product/update-product", productData, {
                headers: { "Content-Type": "multipart/form-data" }
            });
            console.log("Product Updated:", res.data);
            alert("Product updated successfully!");
            navigate("/all-product"); // Navigate to products page after update
        } catch (error) {
            console.error("Error Response:", error.response?.data);
            alert("Error updating product: " + (error.response?.data?.message || error.message));
        }
    };

    if (loading) {
        return <div className="p-6 text-center">Loading product data...</div>
    }

    return (
        <div className="p-6 max-w-4xl mx-auto bg-white shadow-md rounded-md">
            <h2 className="text-2xl font-bold mb-4">Edit Product</h2>

            <input type="text" name="name" placeholder="Product Name" className="w-full p-2 border rounded mb-2" value={formData.name} onChange={handleChange} />
            <input type="text" name="material" placeholder="Material" className="w-full p-2 border rounded mb-2" value={formData.material} onChange={handleChange} />

            <select name="category" className="w-full p-2 border rounded mb-2" value={formData.category} onChange={handleChange}>
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                <option value="Kids">Kids</option>
            </select>
            
            {/* Discount Controls */}
            <div className="mb-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Discount (%)
                    </label>
                    <input
                        type="number"
                        min="0"
                        max="100"
                        className="w-full p-2 border rounded"
                        value={formData.discount}
                        onChange={handleDiscountChange}
                        placeholder="0-100"
                    />
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Discount Ends On
                    </label>
                    <input
                        type="date"
                        className="w-full p-2 border rounded"
                        value={formData.discountEndDate}
                        onChange={handleDiscountEndDateChange}
                        min={new Date().toISOString().split('T')[0]}
                        disabled={formData.discount <= 0}
                    />
                </div>
            </div>

            {/* Display Discount Preview */}
            {formData.discount > 0 && (
                <div className="mb-4 p-3 bg-blue-50 rounded-md">
                    <h4 className="font-medium text-blue-800 mb-2">Discount Preview</h4>
                    <p className="text-sm">
                        {formData.discount}% OFF
                        {formData.discountEndDate && (
                            <span> (Ends on {new Date(formData.discountEndDate).toLocaleDateString()})</span>
                        )}
                    </p>
                    {formData.sizes.length > 0 && (
                        <div className="mt-2">
                            <p className="text-sm font-medium">Price adjustments:</p>
                            {formData.sizes.map((size, index) => (
                                <div key={index} className="flex items-center mt-1 text-sm">
                                    <span className="font-medium mr-2">{size.size}:</span>
                                    <span className="text-gray-500 line-through mr-2">
                                        ${size.price.toFixed(2)}
                                    </span>
                                    <span className="text-green-600 font-medium">
                                        ${size.DiscountedPrice.toFixed(2)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
             
            <h3 className="text-lg font-semibold mb-2">Product Images</h3>
            <p className="text-sm text-gray-600 mb-2">You can upload up to 4 images in total.</p>
            
            {/* Existing images */}
            <div className="mb-4">
                <h4 className="font-medium mb-2">Current Images:</h4>
                <div className="flex gap-2 mt-2 flex-wrap">
                    {existingImages.map((img, index) => (
                        <div key={index} className="relative">
                            {!img.isDeleted ? (
                                <>
                                    <img 
                                        src={`${BASE_URL}${img.path}`} 
                                        alt="Product" 
                                        className="w-20 h-20 object-cover border" 
                                    />
                                    <button
                                        onClick={() => handleRemoveExistingImage(index)}
                                        className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full text-xs"
                                    >
                                        x
                                    </button>
                                </>
                            ) : (
                                <div className="w-20 h-20 border flex items-center justify-center bg-gray-100">
                                    <button
                                        onClick={() => handleRestoreExistingImage(index)}
                                        className="text-blue-500"
                                    >
                                        Restore
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* Upload new images */}
            {(existingImages.filter(img => !img.isDeleted).length + formData.images.length) < 4 && (
                <input 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    onChange={handleImageUpload} 
                    className="w-full p-2 border rounded mb-2" 
                />
            )}

            {/* New images preview */}
            {formData.images.length > 0 && (
                <div className="mb-4">
                    <h4 className="font-medium mb-2">New Images:</h4>
                    <div className="flex gap-2 mt-2 flex-wrap">
                        {formData.images.map((img, index) => (
                            <div key={index} className="relative">
                                <img 
                                    src={URL.createObjectURL(img)} 
                                    alt="Preview" 
                                    className="w-20 h-20 object-cover border" 
                                />
                                <button
                                    onClick={() => handleRemoveNewImage(index)}
                                    className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full text-xs"
                                >
                                    x
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            <div className="mb-4">
                <h3 className="text-lg font-semibold mb-2">Size Chart</h3>
                
                {/* Existing Size Chart */}
                {existingSizeChartImage && !formData.sizeChartImage && (
                    <div className="mb-4">
                        <h4 className="font-medium mb-2">Current Size Chart:</h4>
                        <div className="relative">
                            <img 
                                src={`${BASE_URL}${existingSizeChartImage}`} 
                                alt="Size Chart" 
                                className="w-full max-w-md h-auto border rounded" 
                            />
                            <button
                                onClick={handleRemoveSizeChart}
                                className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full text-xs"
                            >
                                ×
                            </button>
                        </div>
                    </div>
                )}

                {/* New Size Chart Upload */}
                <div className="mb-2">
                    <p className="text-sm text-gray-600 mb-2">Upload new size chart:</p>
                    <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleSizeChartUpload} 
                        className="w-full p-2 border rounded" 
                    />
                </div>

                {/* New Size Chart Preview */}
                {formData.sizeChartImage && (
                    <div className="mt-4">
                        <h4 className="font-medium mb-2">New Size Chart Preview:</h4>
                        <div className="relative">
                            <img 
                                src={URL.createObjectURL(formData.sizeChartImage)} 
                                alt="Size Chart Preview" 
                                className="w-full max-w-md h-auto border rounded" 
                            />
                            <button
                                onClick={handleRemoveSizeChart}
                                className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full text-xs"
                            >
                                ×
                            </button>
                        </div>
                    </div>
                )}
            </div>

            <textarea name="description" placeholder="Description" className="w-full p-2 border rounded mb-2" value={formData.description} onChange={handleChange}></textarea>

            <h3 className="text-lg font-semibold mb-2">Sizes & Colors</h3>
            {formData.sizes.map((size, sizeIndex) => (
                <div key={sizeIndex} className="border p-4 mb-2">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                        <div>
                            <label className="block text-sm font-medium mb-1">Size</label>
                            <input 
                                type="text" 
                                placeholder="Size" 
                                className="w-full p-2 border rounded" 
                                value={size.size} 
                                onChange={(e) => handleSizeChange(sizeIndex, "size", e.target.value)} 
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Price</label>
                            <input 
                                type="number" 
                                placeholder="Price" 
                                className="w-full p-2 border rounded" 
                                value={size.price} 
                                onChange={(e) => handlePriceChange(sizeIndex, e.target.value)} 
                                min="0"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">
                                {formData.discount > 0 ? "Discounted Price" : "Price"}
                            </label>
                            <input 
                                type="number" 
                                className="w-full p-2 border rounded bg-gray-100" 
                                value={size.DiscountedPrice} 
                                readOnly
                            />
                        </div>
                    </div>

                    <button className="bg-blue-500 text-black p-2 rounded ml-2" onClick={() => handleAddColor(sizeIndex)}>+ Add Color</button>

                    {size.colors.map((color, colorIndex) => (
                        <div key={colorIndex} className="mt-2 p-2 border rounded">
                            <input type="text" placeholder="Color" className="p-2 border rounded w-1/3" value={color.color} onChange={(e) => handleColorChange(sizeIndex, colorIndex, "color", e.target.value)} />
                            <input type="number" placeholder="Stock" className="p-2 border rounded w-1/3 ml-2" value={color.stock} onChange={(e) => handleColorChange(sizeIndex, colorIndex, "stock", e.target.value)} />
                            
                            {/* Show existing color image if available */}
                            {existingColorImages.map((img, i) => {
                                if (img.sizeIndex === sizeIndex && 
                                    img.colorIndex === colorIndex && 
                                    !img.isDeleted) {
                                    return (
                                        <div key={i} className="mt-2 relative">
                                            <img 
                                                src={`${BASE_URL}${img.path}`} 
                                                alt="Color" 
                                                className="w-20 h-20 object-cover border" 
                                            />
                                            <p className="text-sm text-gray-600">Current color image</p>
                                        </div>
                                    );
                                }
                                return null;
                            })}
                            
                            <div className="mt-2">
                                <p className="text-sm text-gray-600">Upload new color image:</p>
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    className="p-2 border rounded w-full" 
                                    onChange={(e) => handleColorChange(sizeIndex, colorIndex, "image", e.target.files?.[0])} 
                                />
                            </div>
                            
                            {/* Preview for new color image */}
                            {color.image && (
                                <div className="mt-2">
                                    <img 
                                        src={URL.createObjectURL(color.image)} 
                                        alt="Color Preview" 
                                        className="w-20 h-20 object-cover border" 
                                    />
                                    <p className="text-sm text-gray-600">New color image</p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            ))}

            <button className="bg-green-500 text-black p-2 rounded mb-4" onClick={handleAddSize}>+ Add Size</button>

            <button onClick={handleSubmit} className="w-full bg-blue-600 text-black p-3 rounded-lg font-semibold shadow-md hover:bg-blue-700">Update Product</button>
        </div>
    );
};

export default EditProduct;