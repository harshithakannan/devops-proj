import React, { useState, useEffect } from "react";
import { Search, Filter, ChevronDown, Star, Heart, ShoppingBag, ChevronLeft, ChevronRight, X } from "lucide-react";
import API from "../api";
import { colorNameToHex } from './Colorname';

const ProductListing = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    category: "",
    priceRange: "",
    material: ""
  });
  const [sortOption, setSortOption] = useState("featured");
  const [showFilters, setShowFilters] = useState(false);
  const [materials, setMaterials] = useState([]);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [colorPopupImage, setColorPopupImage] = useState(null);
  const [showSizeChart, setShowSizeChart] = useState(false);
  
  const BASE_URL = "http://localhost:5006/";

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const response = await API.get("/product/display_products");
        setProducts(response.data);
        setFilteredProducts(response.data);
        
        const uniqueMaterials = [...new Set(response.data.map(product => product.material))];
        setMaterials(uniqueMaterials);
        
        setLoading(false);
      } catch (err) {
        setError("Failed to load products. Please try again later.");
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const getImageUrl = (imagePath) => {
    if (!imagePath) return '/placeholder.jpg';
    if (imagePath.startsWith('http')) return imagePath;
    return `${BASE_URL}${imagePath}`;
  };

  useEffect(() => {
    let result = [...products];
    
    if (searchQuery) {
      result = result.filter(product => 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.material.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (filters.category) {
      result = result.filter(product => product.category === filters.category);
    }
    
    if (filters.material) {
      result = result.filter(product => product.material === filters.material);
    }
    
    if (filters.priceRange) {
      const [min, max] = filters.priceRange.split("-").map(Number);
      result = result.filter(product => {
        const mediumSizeIndex = Math.floor(product.sizes.length / 2);
        const price = product.discount > 0 
          ? product.sizes[mediumSizeIndex].DiscountedPrice 
          : product.sizes[mediumSizeIndex].price;
        
        return price >= min && (max ? price <= max : true);
      });
    }
    
    switch (sortOption) {
      case "price-low-high":
        result.sort((a, b) => {
          const priceA = getDisplayPrice(a);
          const priceB = getDisplayPrice(b);
          return priceA - priceB;
        });
        break;
      case "price-high-low":
        result.sort((a, b) => {
          const priceA = getDisplayPrice(a);
          const priceB = getDisplayPrice(b);
          return priceB - priceA;
        });
        break;
      case "newest":
        result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case "discount":
        result.sort((a, b) => b.discount - a.discount);
        break;
      default:
        break;
    }
    
    setFilteredProducts(result);
  }, [products, searchQuery, filters, sortOption]);

  const getDisplayPrice = (product) => {
    const mediumSizeIndex = Math.floor(product.sizes.length / 2);
    return product.discount > 0 
      ? product.sizes[mediumSizeIndex].DiscountedPrice 
      : product.sizes[mediumSizeIndex].price;
  };

  const getOriginalPrice = (product) => {
    const mediumSizeIndex = Math.floor(product.sizes.length / 2);
    return product.sizes[mediumSizeIndex].price;
  };

  const openProductDetail = (product) => {
    setSelectedProduct(product);
    setSelectedSize(product.sizes[0].size);
    setSelectedColor(product.sizes[0].colors[0].color);
    setCurrentImageIndex(0);
  };

  const closeProductDetail = () => {
    setSelectedProduct(null);
    setSelectedSize("");
    setSelectedColor("");
    setCurrentImageIndex(0);
  };

  const getAvailableColors = () => {
    if (!selectedProduct || !selectedSize) return [];
    
    const sizeObj = selectedProduct.sizes.find(s => s.size === selectedSize);
    return sizeObj ? sizeObj.colors : [];
  };

  const getSelectedSizePrice = () => {
    if (!selectedProduct || !selectedSize) return { price: 0, discountedPrice: 0 };
    
    const sizeObj = selectedProduct.sizes.find(s => s.size === selectedSize);
    if (!sizeObj) return { price: 0, discountedPrice: 0 };
    
    return {
      price: sizeObj.price,
      discountedPrice: selectedProduct.discount > 0 ? sizeObj.DiscountedPrice : sizeObj.price
    };
  };

  const formatPrice = (price) => {
    return `₹${price.toLocaleString('en-IN')}`;
  };

  const isDiscountActive = (product) => {
    if (!product.discount || product.discount <= 0) return false;
    if (!product.discountEndDate) return true;
    
    return new Date(product.discountEndDate) > new Date();
  };

  const handlePrevImage = (e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (!selectedProduct?.images?.length) return;
    setCurrentImageIndex(prev => 
      prev === 0 ? selectedProduct.images.length - 1 : prev - 1
    );
  };

  const handleNextImage = (e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (!selectedProduct?.images?.length) return;
    setCurrentImageIndex(prev => 
      prev === selectedProduct.images.length - 1 ? 0 : prev + 1
    );
  };

  const findColorImage = (color) => {
    if (!selectedProduct) return null;
    
    const sizeObj = selectedProduct.sizes.find(s => s.size === selectedSize);
    if (!sizeObj) return null;
    
    const colorObj = sizeObj.colors.find(c => c.color === color);
    if (!colorObj || !colorObj.image) return null;
    
    return colorObj.image;
  };

  const handleThumbnailClick = (index, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    setCurrentImageIndex(index);
  };

  const handleColorClick = (colorObj, e) => {
    if (e) e.stopPropagation();
    
    setSelectedColor(colorObj.color);
    
    const colorImage = findColorImage(colorObj.color);
    if (colorImage) {
      // Show popup if this color has a specific image
      setColorPopupImage(colorImage);
    } else {
      // Otherwise check if this color's image exists in main images array
      const sizeObj = selectedProduct.sizes.find(s => s.size === selectedSize);
      if (sizeObj) {
        const colorObj = sizeObj.colors.find(c => c.color === colorObj.color);
        if (colorObj?.image) {
          const imageIndex = selectedProduct.images.findIndex(img => img === colorObj.image);
          if (imageIndex >= 0) {
            setCurrentImageIndex(imageIndex);
          }
        }
      }
    }
  };

  
  const openSizeChart = (selectedProduct) => {
    setShowSizeChart(true);
  };

  const closeSizeChart = () => {
    setShowSizeChart(false);
  };

  // Get similar products (by category)
  const getSimilarProducts = () => {
    if (!selectedProduct) return [];
    
    return filteredProducts
      .filter(product => 
        product._id !== selectedProduct._id && 
        product.category === selectedProduct.category
      )
      .slice(0, 4); // Show max 4 similar products
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      </div>
    );
  }

  // Product Detail View
  if (selectedProduct) {
    const { price, discountedPrice } = getSelectedSizePrice();
    const hasDiscount = isDiscountActive(selectedProduct);
    const similarProducts = getSimilarProducts();
    
    return (
      <div className="min-h-screen bg-gray-50 py-6 px-4 sm:px-6 lg:px-8">
        {/* Color Popup Modal */}
        {colorPopupImage && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="relative max-w-4xl w-full bg-white rounded-lg overflow-hidden">
              <button 
                onClick={() => setColorPopupImage(null)}
                className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-lg z-10"
              >
                <X size={24} />
              </button>
              <img 
                src={getImageUrl(colorPopupImage)} 
                alt={`${selectedProduct.name} - ${selectedColor}`}
                className="w-full h-full object-contain max-h-[80vh]"
              />
            </div>
          </div>
        )}
        
        <button 
          onClick={closeProductDetail}
          className="mb-6 flex items-center text-indigo-600 hover:text-indigo-800"
        >
          <ChevronDown className="transform rotate-90 mr-1" size={16} />
          Back to Products
        </button>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Product Images */}
            <div className="p-6 lg:col-span-1">
              {/* Main Image with Navigation Controls */}
              <div className="relative mb-4">
                <img 
                  src={getImageUrl(
                    selectedProduct.images?.[currentImageIndex] || 
                    selectedProduct.images?.[0] ||
                    '/placeholder-image.jpg'
                  )} 
                  alt={selectedProduct.name} 
                  className="w-full h-96 object-cover rounded-lg"
                  onError={(e) => {
                    e.target.src = '/placeholder-image.jpg';
                    e.target.onerror = null;
                  }}
                />
                
                {selectedProduct.images?.length > 1 && (
                  <>
                    <button 
                      onClick={handlePrevImage}
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-70 rounded-full p-1 shadow hover:bg-opacity-100 focus:outline-none"
                      aria-label="Previous image"
                    >
                      <ChevronLeft size={24} className="text-gray-800" />
                    </button>
                    <button 
                      onClick={handleNextImage}
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-70 rounded-full p-1 shadow hover:bg-opacity-100 focus:outline-none"
                      aria-label="Next image"
                    >
                      <ChevronRight size={24} className="text-gray-800" />
                    </button>
                  </>
                )}
              </div>
              
              {/* Thumbnail Images */}
              {selectedProduct.images?.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {selectedProduct.images?.map((image, index) => (
                    <button 
                      key={index}
                      className={`p-0 border-0 bg-transparent focus:outline-none ${
                        index === currentImageIndex ? 'ring-2 ring-indigo-500' : ''
                      }`}
                      onClick={(e) => handleThumbnailClick(index, e)}
                      aria-label={`View image ${index + 1}`}
                    >
                      <img 
                        src={getImageUrl(image)} 
                        alt={`${selectedProduct.name} - view ${index + 1}`}
                        className={`w-full h-20 object-cover rounded-md border-2 cursor-pointer ${
                          index === currentImageIndex ? 'border-indigo-500' : 'border-gray-300'
                        }`}
                        onError={(e) => {
                          e.target.src = '/placeholder-image.jpg';
                          e.target.onerror = null;
                        }}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Middle Column - Product Details */}
            <div className="p-6 lg:col-span-1">
              <h1 className="text-2xl font-bold text-gray-800 mb-2">{selectedProduct.name}</h1>
              <p className="text-gray-500 mb-4">{selectedProduct.material}</p>
              
              <div className="flex items-center mb-4">
                <div className="flex items-center bg-green-100 text-green-800 px-2 py-1 rounded">
                  <Star size={16} fill="currentColor" className="mr-1" />
                  <span>4.5</span>
                </div>
                <span className="text-gray-400 text-sm ml-2">based on 120 reviews</span>
              </div>
              
              <div className="mb-6">
                {hasDiscount ? (
                  <div className="flex items-center">
                    <span className="text-2xl font-bold text-gray-800">{formatPrice(discountedPrice)}</span>
                    <span className="ml-2 text-lg text-gray-400 line-through">{formatPrice(price)}</span>
                    <span className="ml-2 text-green-600 font-medium">
                      {selectedProduct.discount}% OFF
                    </span>
                  </div>
                ) : (
                  <span className="text-2xl font-bold text-gray-800">{formatPrice(price)}</span>
                )}
                
                {hasDiscount && selectedProduct.discountEndDate && (
                  <p className="text-sm text-red-600 mt-1">
                    Offer ends on {new Date(selectedProduct.discountEndDate).toLocaleDateString()}
                  </p>
                )}
              </div>
              
              {/* Size Selection */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Select Size</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedProduct.sizes.map((size) => (
                    <button
                      key={size.size}
                      className={`px-4 py-2 border rounded-md ${
                        selectedSize === size.size 
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-600' 
                          : 'border-gray-300 text-gray-700 hover:border-gray-400'
                      }`}
                      onClick={() => setSelectedSize(size.size)}
                    >
                      {size.size}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Color Selection */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Select Color</h3>
                <div className="flex flex-wrap gap-3">
                  {getAvailableColors().map((colorObj) => {
                    const hexColor = colorObj.hexCode || colorNameToHex(colorObj.color) || "#CCCCCC";
                    
                    return (
                      <button
                        key={colorObj.color}
                        className={`relative w-10 h-10 rounded-full border-2 ${
                          selectedColor === colorObj.color 
                            ? 'border-indigo-600 ring-2 ring-indigo-300' 
                            : 'border-gray-300'
                        }`}
                        onClick={(e) => handleColorClick(colorObj, e)}
                        title={colorObj.color}
                      >
                        <div 
                          className="absolute inset-0 rounded-full" 
                          style={{ backgroundColor: hexColor }}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
             
              {/* Action Buttons */}
              <div className="flex gap-4 mb-8">
                <button className="flex-1 flex items-center justify-center bg-indigo-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-indigo-700">
                  <ShoppingBag size={18} className="mr-2" />
                  Add to Bag
                </button>
                <button className="flex items-center justify-center border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50">
                  <Heart size={18} />
                </button>
              </div>
              
              {/* Description */}
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Description</h3>
                <p className="text-gray-600">{selectedProduct.description}</p>
              </div>
              
              {/* Size Chart */}
              {selectedProduct.sizeChartImage && (
                <button
                  onClick={() => openSizeChart(selectedProduct)}
                  className="mb-4 text-blue-600 hover:text-blue-800 underline text-sm"
                >
                  View Size Chart
                </button>
              )}
            </div>
            {showSizeChart && selectedProduct?.sizeChartImage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">{selectedProduct.name} Size Chart</h2>
                <button 
                  onClick={closeSizeChart}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              <img 
                src={`${BASE_URL}${selectedProduct.sizeChartImage}`}
                alt="Size Chart"
                className="w-full h-auto object-contain"
                onError={(e) => {
                  e.target.src = '/placeholder-size-chart.jpg';
                  e.target.onerror = null;
                }}
              />
              <div className="mt-4 flex justify-end">
                <button
                  onClick={closeSizeChart}
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
            
            {/* Right Column - Similar Products */}
            <div className="p-6 lg:col-span-1">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Similar Products</h2>
              
              {similarProducts.length > 0 ? (
                <div className="grid grid-cols-2 gap-4">
                  {similarProducts.map(product => {
                    const hasDiscount = isDiscountActive(product);
                    const mediumSizeIndex = Math.floor(product.sizes.length / 2);
                    const displayPrice = hasDiscount 
                      ? product.sizes[mediumSizeIndex].DiscountedPrice 
                      : product.sizes[mediumSizeIndex].price;
                    const originalPrice = product.sizes[mediumSizeIndex].price;
                    
                    return (
                      <div 
                        key={product._id}
                        className="bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => openProductDetail(product)}
                      >
                        <div className="relative h-40">
                          <img 
                            src={getImageUrl(product.images[0])} 
                            alt={product.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.target.src = '/placeholder-image.jpg';
                              e.target.onerror = null;
                            }}
                          />
                          {hasDiscount && (
                            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs font-bold px-1 py-0.5 rounded">
                              {product.discount}% OFF
                            </div>
                          )}
                        </div>
                        <div className="p-2">
                          <h3 className="text-sm font-medium text-gray-800 line-clamp-1">{product.name}</h3>
                          <div className="flex items-center mt-1">
                            <span className="text-sm font-medium text-gray-900">{formatPrice(displayPrice)}</span>
                            {hasDiscount && (
                              <span className="ml-1 text-xs text-gray-400 line-through">{formatPrice(originalPrice)}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-gray-500">No similar products found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Product Listing View
  return (
    <div className="min-h-screen w-screen bg-gray-50 py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Explore Our Collection</h1>
        
        {/* Search Bar */}
        <div className="mb-6 relative">
          <div className="flex items-center w-full bg-white rounded-lg overflow-hidden shadow-lg border-2 border-indigo-200">
            <div className="pl-4">
              <Search size={22} className="text-indigo-500" />
            </div>
            <input
              type="text"
              placeholder="Search products by name, material or description..."
              className="w-full py-4 px-4 focus:outline-none text-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {/* Filter and Sort Options */}
        <div className="mb-6 flex flex-wrap gap-4 items-center justify-between">
          <div className="flex items-center">
              <button 
              className="flex items-center bg-indigo-50 py-3 px-5 rounded-lg shadow-md mr-4 border-2 border-indigo-200 hover:bg-indigo-100 transition-colors duration-200"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter size={20} className="mr-2 text-indigo-600" />
              <span className="text-indigo-700 font-medium">Filters</span>
              <ChevronDown 
                size={18} 
                className={`ml-2 transition-transform text-indigo-600 ${showFilters ? 'transform rotate-180' : ''}`} 
              />
            </button>
            
            {/* Category Pills */}
            <div className="flex flex-wrap gap-2">
              <button 
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  filters.category === "" 
                    ? "bg-indigo-100 text-indigo-800" 
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
                onClick={() => setFilters(prev => ({ ...prev, category: "" }))}
              >
                All
              </button>
              <button 
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  filters.category === "Men" 
                    ? "bg-indigo-100 text-indigo-800" 
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
                onClick={() => setFilters(prev => ({ ...prev, category: "Men" }))}
              >
                Men
              </button>
              <button 
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  filters.category === "Women" 
                    ? "bg-indigo-100 text-indigo-800" 
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
                onClick={() => setFilters(prev => ({ ...prev, category: "Women" }))}
              >
                Women
              </button>
              <button 
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  filters.category === "Kids" 
                    ? "bg-indigo-100 text-indigo-800" 
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
                onClick={() => setFilters(prev => ({ ...prev, category: "Kids" }))}
              >
                Kids
              </button>
            </div>
          </div>
          
          {/* Sort Options */}
          <div className="relative">
          <select
            className="appearance-none bg-indigo-50 py-3 pl-4 pr-10 rounded-lg shadow-md border-2 border-indigo-200 cursor-pointer font-medium text-indigo-700"
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
          >
            <option value="featured">Featured</option>
            <option value="price-low-high">Price: Low to High</option>
            <option value="price-high-low">Price: High to Low</option>
            <option value="newest">Newest First</option>
            <option value="discount">Biggest Discount</option>
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3">
            <ChevronDown size={20} className="text-indigo-600" />
          </div>
        </div>
        </div>
        
        {/* Extended Filters */}
        {showFilters && (
          <div className="mb-8 p-6 bg-white rounded-lg shadow-md border border-indigo-100">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Material Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Material</label>
                <select
                  className="w-full border border-gray-300 rounded-md p-2"
                  value={filters.material}
                  onChange={(e) => setFilters(prev => ({ ...prev, material: e.target.value }))}
                >
                  <option value="">All Materials</option>
                  {materials.map(material => (
                    <option key={material} value={material}>{material}</option>
                  ))}
                </select>
              </div>
              
              {/* Price Range Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <select
                  className="w-full border-2 border-gray-300 rounded-md p-3 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  value={filters.material}
                  onChange={(e) => setFilters(prev => ({ ...prev, material: e.target.value }))}
                >
                  <option value="">All Prices</option>
                  <option value="0-999">Under ₹999</option>
                  <option value="1000-1999">₹1,000 - ₹1,999</option>
                  <option value="2000-4999">₹2,000 - ₹4,999</option>
                  <option value="5000-9999">₹5,000 - ₹9,999</option>
                  <option value="10000-">₹10,000 and above</option>
                </select>
              </div>
              
              {/* Clear Filters Button */}
              <div className="flex items-end">
                <button 
                  className="text-indigo-600 hover:text-indigo-800 font-medium text-sm py-2 px-4 rounded border border-indigo-200 hover:bg-indigo-50"
                  onClick={() => setFilters({ category: "", priceRange: "", material: "" })}
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'} found
          </p>
        </div>
        
        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => {
              const hasDiscount = isDiscountActive(product);
              const mediumSizeIndex = Math.floor(product.sizes.length / 2);
              const displayPrice = hasDiscount 
                ? product.sizes[mediumSizeIndex].DiscountedPrice 
                : product.sizes[mediumSizeIndex].price;
              const originalPrice = product.sizes[mediumSizeIndex].price;
              
              return (
                <div 
                  key={product._id} 
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer"
                  onClick={() => openProductDetail(product)}
                >
                  {/* Product Image */}
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={getImageUrl(product.images[0])} 
                      alt={product.name} 
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      onError={(e) => {
                        e.target.src = '/placeholder-image.jpg';
                        e.target.onerror = null;
                      }}
                    />
                    
                    {/* Discount Badge */}
                    {hasDiscount && (
                      <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                        {product.discount}% OFF
                      </div>
                    )}
                    
                    {/* Wishlist Button */}
                    <button 
                      className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-md hover:bg-gray-100"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Add to wishlist functionality
                      }}
                    >
                      <Heart size={16} className="text-gray-500" />
                    </button>
                  </div>
                  
                  {/* Product Info */}
                  <div className="p-4">
                    <h3 className="text-sm font-medium text-gray-900 line-clamp-1">{product.name}</h3>
                    <p className="text-xs text-gray-500 mb-2">{product.material}</p>
                    
                    <div className="flex items-center mt-1">
                      <span className="font-medium text-gray-900">{formatPrice(displayPrice)}</span>
                      {hasDiscount && (
                        <span className="ml-2 text-xs text-gray-400 line-through">{formatPrice(originalPrice)}</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductListing;