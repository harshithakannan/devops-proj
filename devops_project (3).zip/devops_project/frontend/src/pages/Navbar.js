// Navbar.js
import { FaShoppingCart, FaUser, FaSearch } from "react-icons/fa";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <h1 className="text-2xl font-bold text-gray-900">FLUFFY TOWN</h1>
      <div className="flex items-center border border-gray-400 rounded-lg overflow-hidden w-full max-w-lg">
        <input
          type="text"
          placeholder="Search..."
          className="w-full h-12 px-4 text-lg focus:outline-none"
        />
        <FaSearch className="text-gray-600 mx-3 text-2xl cursor-pointer" />
      </div>
      <div className="flex space-x-6 text-gray-700">
        <FaShoppingCart className="text-2xl cursor-pointer" />
        <Link to="/login">
          <FaUser className="text-2xl cursor-pointer text-black" />
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;