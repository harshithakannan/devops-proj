import React, { useState, useEffect } from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

const ProductCard = () => {
  const [products, setProducts] = useState([]);
  const [currentImageIndices, setCurrentImageIndices] = useState({});
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [showSizeChart, setShowSizeChart] = useState(false);
  const [currentProduct, setCurrentProduct] = useState(null);

  const BASE_URL = "http://localhost:5006/";
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await API.get('/product/display_products');
        setProducts(response.data);
        console.log(response.data);
        // Initialize image indices for each product
        const initialIndices = {};
        response.data.forEach(product => {
          initialIndices[product._id] = 0;
        });
        setCurrentImageIndices(initialIndices);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    fetchProducts();
  }, []);

  // Auto-advance slideshow for each product
  useEffect(() => {
    if (products.length > 0) {
      const intervals = products.map(product => {
        return setInterval(() => {
          setCurrentImageIndices(prev => ({
            ...prev,
            [product._id]: (prev[product._id] + 1) % product.images.length
          }));
        }, 3000);
      });

      return () => intervals.forEach(interval => clearInterval(interval));
    }
  }, [products]);

  const handleImageClick = (productId, index) => {
    setCurrentImageIndices(prev => ({
      ...prev,
      [productId]: index
    }));
  };

  const handleSizeClick = (product, size, colorIndex = 0) => {
    setCurrentProduct(product);
    setSelectedSize(size);
    const defaultColor = size.colors[colorIndex];
    setSelectedColor(defaultColor);
  };

  const handleColorSelect = (color) => {
    setSelectedColor(color);
  };

  const handleDelete = async (productId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this product?");
    if (!confirmDelete) return;

    try {
      await API.delete(`/product/delete/${productId}`);
      setProducts(products.filter((product) => product._id !== productId));
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };
  
  const handleEdit = (productId) => {
    navigate(`/edit-product/${productId}`);
  };

  const openSizeChart = (product) => {
    setCurrentProduct(product);
    setShowSizeChart(true);
  };

  const closeSizeChart = () => {
    setShowSizeChart(false);
  };

  // Helper function to format discount information
  const renderDiscountInfo = (size) => {
    if (!size.price || size.price <= size.DiscountedPrice) {
      return null;
    }
    const discountPercentage = Math.round(
      ((size.price - size.DiscountedPrice) / size.price) * 100
    );

    return (
      <div className="flex items-center mt-1 text-sm">
        <span className="text-gray-500 line-through mr-2">
          ${size.price}
        </span>
        <span className="text-green-600 font-medium">
          ${size.DiscountedPrice} ({discountPercentage}% OFF)
        </span>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Our Products</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {products.map((product) => (
          <div key={product._id} className="bg-white rounded-lg shadow-md max-w-full overflow-hidden hover:shadow-lg transition-shadow duration-300">
            {/* Image Slideshow */}
            <div className="relative h-64 overflow-hidden">
              {product.images.length > 0 ? (
                product.images.map((image, index) => (
                  <img
                    key={index}
                    src={`${BASE_URL}${image}`}
                    alt={product.name}
                    className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
                      index === currentImageIndices[product._id] ? 'opacity-100' : 'opacity-0'
                    }`}
                    onError={(e) => {
                      e.target.src = '/placeholder-image.jpg';
                      e.target.onerror = null;
                    }}
                  />
                ))
              ) : (
                <div className="absolute inset-0 bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500">No images available</span>
                </div>
              )}
              
              {/* Slideshow indicators */}
              {product.images.length > 0 && (
                <div className="absolute bottom-2 left-0 right-0 flex justify-center space-x-2">
                  {product.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => handleImageClick(product._id, index)}
                      className={`w-2 h-2 rounded-full ${
                        index === currentImageIndices[product._id] ? 'bg-white' : 'bg-gray-400'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Product Info */}
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="text-gray-600 mb-2">{product.material}</p>
              <p className="text-gray-700 mb-4">{product.description}</p>
              
              {/* Product-level discount info */}
              {product.discount > 0 && (
                <div className="mb-3 p-2 bg-yellow-50 rounded-md">
                  <div className="flex items-center">
                    <span className="bg-red-500 text-white text-xs px-2 py-1 rounded mr-2">
                      SALE
                    </span>
                    <span className="text-red-600 font-medium">
                      {product.discount}% OFF
                    </span>
                    {product.discountEndDate && (
                      <span className="text-xs text-gray-500 ml-2">
                        (Ends {new Date(product.discountEndDate).toLocaleDateString()})
                      </span>
                    )}
                  </div>
                </div>
              )}
              
              {/* Size Chart Button */}
              {product.sizeChartImage && (
                <button
                  onClick={() => openSizeChart(product)}
                  className="mb-4 text-blue-600 hover:text-blue-800 underline text-sm"
                >
                  View Size Chart
                </button>
              )}
              
              {/* Sizes */}
              <div className="mb-4">
                <h3 className="font-medium mb-2">Available Sizes:</h3>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size, sizeIndex) => (
                    <div key={sizeIndex} className="w-full">
                      <button
                        onClick={() => handleSizeClick(product, size)}
                        className={`w-full px-3 py-2 rounded border ${
                          selectedSize?.size === size.size && currentProduct?._id === product._id
                            ? 'bg-blue-500 text-white border-blue-500'
                            : 'bg-white text-gray-800 border-gray-300'
                        } hover:bg-blue-100 transition-colors text-left`}
                      >
                        <div className="flex justify-between items-center">
                          <span>{size.size}</span>
                          <span className="font-medium">
                            ${size.price}
                          </span>
                        </div>
                        {renderDiscountInfo(size)}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Colors - Only show if size is selected for this product */}
              {selectedSize && currentProduct?._id === product._id && (
                <div className="mb-4">
                  <h3 className="font-medium mb-2">Available Colors:</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedSize.colors.map((color, colorIndex) => (
                      <button
                        key={colorIndex}
                        onClick={() => handleColorSelect(color)}
                        className={`flex items-center px-3 py-1 rounded border ${
                          selectedColor?.color === color.color
                            ? 'bg-blue-100 border-blue-300'
                            : 'bg-white border-gray-300'
                        } hover:bg-blue-50 transition-colors`}
                      >
                        <span 
                          className="w-4 h-4 rounded-full mr-2 border border-gray-300"
                          style={{ backgroundColor: color.color.toLowerCase() }}
                        />
                        {color.color} ({color.stock} left)
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Display selected color image - Only for current product */}
              {selectedColor?.image && currentProduct?._id === product._id && (
                <div className="mt-4">
                  <img 
                    src={`${BASE_URL}${selectedColor.image}`}
                    alt={`${selectedColor.color} variant`}
                    className="w-full h-32 object-contain border rounded"
                    onError={(e) => {
                      e.target.src = '/placeholder-color.jpg';
                      e.target.onerror = null;
                    }}
                  />
                </div>
              )}

              {/* Edit & Delete Buttons */}
              <div className="flex justify-between mt-4">
                <button
                  onClick={() => handleEdit(product._id)}
                  className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-yellow-600 transition"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(product._id)}
                  className="bg-red-500 text-black px-4 py-2 rounded hover:bg-red-600 transition"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Size Chart Modal */}
      {showSizeChart && currentProduct?.sizeChartImage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">{currentProduct.name} Size Chart</h2>
                <button 
                  onClick={closeSizeChart}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              <img 
                src={`${BASE_URL}${currentProduct.sizeChartImage}`}
                alt="Size Chart"
                className="w-full h-auto object-contain"
                onError={(e) => {
                  e.target.src = '/placeholder-size-chart.jpg';
                  e.target.onerror = null;
                }}
              />
              <div className="mt-4 flex justify-end">
                <button
                  onClick={closeSizeChart}
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductCard;