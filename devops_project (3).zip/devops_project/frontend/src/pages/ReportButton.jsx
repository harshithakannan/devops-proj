import React from 'react';
import API from '../api';
import { FileText, Download, FileSpreadsheet } from 'lucide-react';

const ReportButton = () => {
  const downloadReport = async (type) => {
    try {
      // Show loading state
      const buttonElement = document.getElementById(`download-${type}-btn`);
      const originalText = buttonElement.innerHTML;
      buttonElement.innerHTML = `<span class="flex items-center"><svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Downloading...</span>`;
      
      const response = await API.get(`/reports/stock/${type}`, {
        responseType: 'blob' // Important for file downloads
      });
      
      // Create blob URL
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      const date = new Date().toISOString().split('T')[0];
      link.setAttribute('download', `stock-report-${date}.${type}`);
      document.body.appendChild(link);
      link.click();
      
      // Restore button state
      setTimeout(() => {
        buttonElement.innerHTML = originalText;
      }, 1000);
      
      link.remove();
    } catch (error) {
      console.error('Error downloading report:', error);
      
      // Reset button and show error state
      const buttonElement = document.getElementById(`download-${type}-btn`);
      buttonElement.innerHTML = 'Download Failed';
      buttonElement.classList.add('bg-red-200');
      
      setTimeout(() => {
        if (type === 'pdf') {
          buttonElement.innerHTML = '<span class="flex items-center justify-center"><svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>PDF Report</span>';
        } else {
          buttonElement.innerHTML = '<span class="flex items-center justify-center"><svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>Excel Report</span>';
        }
        buttonElement.classList.remove('bg-red-200');
      }, 2000);
    }
  };

  return (
    <div className="bg-white rounded-lg w-screen shadow-sm border border-gray-100 p-6 mb-8">
      <h2 className="text-xl justify-center items-center font-semibold mb-4 text-gray-800">Stock Reports</h2>
      <p className="text-gray-600 mb-5">Generate and download current inventory reports in your preferred format.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <div className="bg-red-50 px-4 py-3 border-b border-red-100">
            <h3 className="font-medium flex items-center text-red-700">
              <FileText size={18} className="mr-2" />
              PDF Report
            </h3>
          </div>
          <div className="p-4">
            <p className="text-sm text-gray-600 mb-4">Comprehensive report with product images and detailed statistics</p>
            <button
              id="download-pdf-btn"
              onClick={() => downloadReport('pdf')}
              className="w-full bg-gradient-to-r from-red-500 to-rose-500 hover:from-red-600 hover:to-rose-600 text-white py-2 px-4 rounded-md transition flex items-center justify-center"
            >
              <Download size={16} className="mr-2" />
              Download PDF
            </button>
          </div>
        </div>
        
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <div className="bg-green-50 px-4 py-3 border-b border-green-100">
            <h3 className="font-medium flex items-center text-green-700">
              <FileSpreadsheet size={18} className="mr-2" />
              Excel Report
            </h3>
          </div>
          <div className="p-4">
            <p className="text-sm text-gray-600 mb-4">Tabular format for data analysis and inventory management</p>
            <button
              id="download-excel-btn"
              onClick={() => downloadReport('excel')}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white py-2 px-4 rounded-md transition flex items-center justify-center"
            >
              <Download size={16} className="mr-2" />
              Download Excel
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-sm text-gray-500 flex items-center">
        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        Reports contain real-time stock levels and are generated on demand
      </div>
    </div>
  );
};

export default ReportButton;