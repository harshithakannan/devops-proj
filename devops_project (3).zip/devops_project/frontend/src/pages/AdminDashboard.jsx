import { useNavigate } from "react-router-dom";
import { Package, FileText, Plus, Menu, X, Filter, RefreshCcw } from "lucide-react";
import { useState, useEffect } from "react";
import API from "../api";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    totalProducts: 0,
    categories: [],
    lowStockProducts: []
  });
  const [currentImageIndices, setCurrentImageIndices] = useState({});
  
  const BASE_URL = "http://localhost:5006/";
  
  const handleAddProduct = () => {
    navigate("/add-product");
  };
  
  const handleViewProduct = () => {
    navigate("/all-product");
  };
  
  const handleGenerateReport = () => {
    navigate("/generate-stock-report");
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        // Fetch total products count
        const productsCountResponse = await API.get('/admindashboard/count');
        const totalProducts = productsCountResponse.data.count;
        
        // Fetch categories
        const categoriesResponse = await API.get('/admindashboard/categories');
        const categories = categoriesResponse.data.categories;
        
        // Fetch low stock products (items with stock less than 20)
        const lowStockResponse = await API.get('/admindashboard/low-stock?threshold=20');
        const lowStockProducts = lowStockResponse.data.products;
        
        // Initialize image indices for each product
        const initialIndices = {};
        lowStockProducts.forEach(product => {
          if (product.images && product.images.length > 0) {
            initialIndices[product._id] = 0;
          }
        });
        setCurrentImageIndices(initialIndices);
        
        setDashboardData({
          totalProducts,
          categories,
          lowStockProducts
        });
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  // Auto-advance slideshow for each product
  useEffect(() => {
    if (dashboardData.lowStockProducts.length > 0) {
      const intervals = dashboardData.lowStockProducts.map(product => {
        if (product.images && product.images.length > 1) {
          return setInterval(() => {
            setCurrentImageIndices(prev => ({
              ...prev,
              [product._id]: ((prev[product._id] || 0) + 1) % product.images.length
            }));
          }, 3000);
        }
        return null;
      }).filter(Boolean);

      return () => intervals.forEach(interval => clearInterval(interval));
    }
  }, [dashboardData.lowStockProducts]);

  const handleImageClick = (productId, index) => {
    setCurrentImageIndices(prev => ({
      ...prev,
      [productId]: index
    }));
  };
  
  return (
    <div className="flex w-screen h-screen bg-gray-50">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-0 -ml-6'} bg-neutral-900 text-white transition-all duration-300 ease-in-out overflow-hidden shadow-xl`}>
        <div className="p-6">
          <h2 className="text-2xl font-bold text-pink-400">FASHION ADMIN</h2>
        </div>
        <div className="px-4 py-2">
          <div className="space-y-3">
            <button 
              onClick={handleAddProduct} 
              className="flex items-center w-full px-4 py-3 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white rounded-md transition"
            >
              <Plus size={18} className="mr-3" />
              <span>Add Product</span>
            </button>
            
            <button 
              onClick={handleViewProduct} 
              className="flex items-center w-full px-4 py-3 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white rounded-md transition"
            >
              <Package size={18} className="mr-3" />
              <span>View Products</span>
            </button>
            
            <button 
              onClick={handleGenerateReport} 
              className="flex items-center w-full px-4 py-3 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white rounded-md transition"
            >
              <FileText size={18} className="mr-3" />
              <span>Generate Report</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header with toggle */}
        <header className="bg-white shadow-sm border-b border-gray-200 py-4 px-6">
          <div className="flex items-center">
            <button 
              onClick={toggleSidebar} 
              className="p-2 mr-4 rounded-full hover:bg-gray-100"
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <h1 className="text-xl font-semibold text-neutral-800">Admin Dashboard</h1>
            {loading && (
              <RefreshCcw size={18} className="ml-3 text-gray-400 animate-spin" />
            )}
          </div>
        </header>
        
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
          <div className="max-w-6xl mx-auto bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome to your Dashboard</h1>
                <p className="text-gray-500">Manage your fashion products and inventory</p>
              </div>
              <div className="h-16 w-16 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                A
              </div>
            </div>
            
            {/* Quick stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-pink-50 p-6 rounded-xl border border-pink-100">
                <p className="text-pink-600 font-medium mb-1">Total Products</p>
                <h3 className="text-3xl font-bold text-gray-800">
                  {loading ? '...' : dashboardData.totalProducts}
                </h3>
              </div>
              
              <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
                <p className="text-purple-600 font-medium mb-1">Categories</p>
                <h3 className="text-3xl font-bold text-gray-800">
                  {loading ? '...' : dashboardData.categories.length}
                </h3>
                <div className="mt-2 flex flex-wrap gap-2">
                  {Array.isArray(dashboardData.categories) && dashboardData.categories.map((category, index) => (
                    <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      {category}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                <p className="text-blue-600 font-medium mb-1">Low Stock Items</p>
                <h3 className="text-3xl font-bold text-gray-800">
                  {loading ? '...' : dashboardData.lowStockProducts.length}
                </h3>
                <p className="text-xs text-blue-600 mt-1">Items with stock below 20</p>
              </div>
            </div>
            
            {/* Low stock products */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800">Low Stock Products</h2>
                <button onClick={() => navigate("/low-stock")} className="flex items-center text-sm text-pink-600 hover:text-pink-800">
                  <Filter size={16} className="mr-1" />
                  View All
                </button>
              </div>
              
              {loading ? (
                <div className="text-center py-8 text-gray-500">Loading product data...</div>
              ) : !Array.isArray(dashboardData.lowStockProducts) || dashboardData.lowStockProducts.length === 0 ? (
                <div className="text-center py-8 text-gray-500">No low stock products found</div>
              ) : (
                <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                    {dashboardData.lowStockProducts.slice(0, 6).map((product, index) => (
                      <div key={index} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden border border-gray-100">
                        {/* Image Slideshow */}
                        <div className="relative h-48 overflow-hidden">
                          {product.images && product.images.length > 0 ? (
                            product.images.map((image, imgIndex) => (
                              <img
                                key={imgIndex}
                                src={`${BASE_URL}${image}`}
                                alt={product.name}
                                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
                                  imgIndex === (currentImageIndices[product._id] || 0) ? 'opacity-100' : 'opacity-0'
                                }`}
                                onError={(e) => {
                                  e.target.src = '/placeholder-image.jpg';
                                  e.target.onerror = null;
                                }}
                              />
                            ))
                          ) : product.mainImage ? (
                            <img
                              src={`${BASE_URL}${product.mainImage}`}
                              alt={product.name}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.target.src = '/placeholder-image.jpg';
                                e.target.onerror = null;
                              }}
                            />
                          ) : (
                            <div className="absolute inset-0 bg-gray-200 flex items-center justify-center">
                              <span className="text-gray-500">No image</span>
                            </div>
                          )}
                          
                          {/* Slideshow indicators */}
                          {product.images && product.images.length > 1 && (
                            <div className="absolute bottom-2 left-0 right-0 flex justify-center space-x-2">
                              {product.images.map((_, imgIndex) => (
                                <button
                                  key={imgIndex}
                                  onClick={() => handleImageClick(product._id, imgIndex)}
                                  className={`w-2 h-2 rounded-full ${
                                    imgIndex === (currentImageIndices[product._id] || 0) ? 'bg-white' : 'bg-gray-400'
                                  }`}
                                />
                              ))}
                            </div>
                          )}
                          
                          {/* Stock indicator */}
                          <div className="absolute top-2 right-2">
                            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                              {product.stock} left
                            </span>
                          </div>
                        </div>
                        
                        {/* Product Info */}
                        <div className="p-4">
                          <h3 className="font-medium text-gray-900">{product.name}</h3>
                          <div className="flex justify-between items-center mt-2">
                            <div className="text-sm text-gray-500">
                              <span>{product.size} / {product.color}</span>
                            </div>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                              {product.category}
                            </span>
                          </div>
                          <button 
                            onClick={() => navigate(`/edit-product/${product._id}`)}
                            className="mt-3 w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white text-sm py-2 rounded-md transition"
                          >
                            Update Stock
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <p className="text-gray-600 mb-4">Use the sidebar to manage your products and access reports.</p>
            
            {/* Mobile buttons (visible only on small screens) */}
            <div className="grid grid-cols-1 gap-4 mt-6 md:hidden">
              <button 
                onClick={handleAddProduct} 
                className="flex items-center justify-center py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-md"
              >
                <Plus size={18} className="mr-2" />
                <span>Add Product</span>
              </button>
              
              <button 
                onClick={handleViewProduct} 
                className="flex items-center justify-center py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-md"
              >
                <Package size={18} className="mr-2" />
                <span>View Products</span>
              </button>
              
              <button 
                onClick={handleGenerateReport} 
                className="flex items-center justify-center py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-md"
              >
                <FileText size={18} className="mr-2" />
                <span>Generate Report</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;