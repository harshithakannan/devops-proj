import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api";

const Login = () => {
    const [formData, setFormData] = useState({
        email: "",
        password: "",
    });

    const [error, setError] = useState("");
    const navigate = useNavigate();

    // ✅ Redirect if token exists
    useEffect(() => {
        const token = localStorage.getItem("token");
        const role = localStorage.getItem("userRole");

        if (token && role) {
            if (role === "admin") {
                navigate("/admin-dashboard");
            } else {
                navigate("/view-product");
            }
        }
    }, [navigate]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const { data } = await API.post("/auth/login", formData);

            // Save token and role
            localStorage.setItem("token", data.token);
            localStorage.setItem("userRole", data.role);

            // Redirect based on role
            if (data.role === "admin") {
                navigate("/admin-dashboard");
            } else {
                navigate("/view-product");
            }
        } catch (err) {
            setError(err.response?.data?.message || "Invalid credentials");
        }
    };

    return (
        <div className="flex justify-center items-center w-screen h-screen bg-[url('https://source.unsplash.com/1600x900/?fashion,shopping')] bg-cover bg-center">
            <div className="bg-white p-10 rounded-lg shadow-2xl w-96 backdrop-blur-md bg-opacity-90">
                <h2 className="text-4xl font-bold text-center text-gray-900 mb-6">Welcome Back to FLUFFY TOWN</h2>
                {error && <p className="text-red-500 text-sm text-center mb-2">{error}</p>}
                <form onSubmit={handleSubmit} className="space-y-5">
                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Enter your password"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                    <button
                        type="submit"
                        className="w-full bg-pink-600 text-black p-3 rounded-lg font-semibold shadow-md hover:bg-pink-700 transition-transform transform hover:scale-105"
                    >
                        Login
                    </button>
                </form>
                <p className="text-sm mt-5 text-center text-gray-700">
                    Don't have an account?{" "}
                    <a href="/signup" className="text-pink-600 font-semibold hover:underline">
                        Sign Up
                    </a>
                </p>
            </div>
        </div>
    );
};

export default Login;
