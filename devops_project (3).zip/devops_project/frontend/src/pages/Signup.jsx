import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api";

const Signup = () => {
    const [formData, setFormData] = useState({
        username: "",
        email: "",
        password: "",
        mobilenumber: "",
    });

    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await API.post("/auth/register", formData);
            console.log("Response:", response.data);
            navigate("/login");
        } catch (err) {
            console.error("Signup error:", err.response);  
            setError(err.response?.data?.message || "Something went wrong");
        }
    };

    return (
        <div className="flex justify-center items-center w-screen h-screen bg-[url('https://source.unsplash.com/1600x900/?fashion,clothing')] bg-cover bg-center">
            <div className="bg-white p-10 rounded-lg shadow-2xl w-96 backdrop-blur-md bg-opacity-90">
                <h2 className="text-4xl font-bold text-center text-gray-900 mb-6">Join DressShop</h2>
                {error && <p className="text-red-500 text-sm text-center mb-2">{error}</p>}
                <form onSubmit={handleSubmit} className="space-y-5">
                    <input
                        type="text"
                        name="username"
                        placeholder="Enter your name"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.username}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Create a password"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="number"
                        name="mobilenumber"
                        placeholder="Enter your mobile number"
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                        value={formData.mobilenumber}
                        onChange={handleChange}
                        required
                    />
                    <button
                        type="submit"
                        className="w-full bg-pink-600 text-black p-3 rounded-lg font-semibold shadow-md hover:bg-pink-700 transition-transform transform hover:scale-105"
                    >
                        Sign Up
                    </button>
                </form>
                <p className="text-sm mt-5 text-center text-gray-700">
                    Already have an account? {" "}
                    <a href="/login" className="text-pink-600 font-semibold hover:underline">
                        Login
                    </a>
                </p>
            </div>
        </div>
    );
};

export default Signup;
