import { useState } from "react";
import API from "../api";

const AddProduct = () => {
    const [formData, setFormData] = useState({
        name: "",
        material: "",
        images: [],
        category: "Men",
        sizes: [{ size: "", price: 0,  DiscountedPrice: 0, colors: [{ color: "", image: null, stock: 0 }] }],
        description: "",
        sizeChartImage: null,
        discount: 0,
        discountEndDate: "",
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleImageUpload = (e) => {
        const files = Array.from(e.target.files);
        if (formData.images.length + files.length > 4) {
            alert("You can only upload up to 4 images.");
            return;
        }
        setFormData((prevData) => ({
            ...prevData,
            images: [...prevData.images, ...files],
        }));
    };

    const handleRemoveImage = (index) => {
        setFormData((prevData) => ({
            ...prevData,
            images: prevData.images.filter((_, i) => i !== index),
        }));
    };

    // New handler for size chart image
    const handleSizeChartUpload = (e) => {
        if (e.target.files && e.target.files[0]) {
            setFormData((prevData) => ({
                ...prevData,
                sizeChartImage: e.target.files[0]
            }));
        }
    };

    // New handler to remove size chart image
    const handleRemoveSizeChart = () => {
        setFormData((prevData) => ({
            ...prevData,
            sizeChartImage: null
        }));
    };

    const handleAddSize = () => {
        setFormData((prev) => ({
            ...prev,
            sizes: [...prev.sizes, { size: "", originalPrice: 0, 
                price: 0,  colors: [{ color: "", image: null, stock: 0 }] }]
        }));
    };

    const handleSizeChange = (index, field, value) => {
        const newSizes = [...formData.sizes];
        newSizes[index][field] = value;
        setFormData(prev => ({ ...prev, sizes: newSizes }));
    };


    const handleAddColor = (sizeIndex) => {
        const newSizes = [...formData.sizes];
        newSizes[sizeIndex].colors.push({ color: "", image: null, stock: 0 });
        setFormData((prev) => ({ ...prev, sizes: newSizes }));
    };
    
    const handleColorChange = (sizeIndex, colorIndex, field, value) => {
        const newSizes = [...formData.sizes];
        if (field === "image") {
            if (value) {
                newSizes[sizeIndex].colors[colorIndex][field] = value;
            }
        } else {
            newSizes[sizeIndex].colors[colorIndex][field] = value;
        }
        setFormData((prev) => ({ ...prev, sizes: newSizes }));
    };

    const handleDiscountChange = (e) => {
        const discountValue = parseInt(e.target.value) || 0;
        const newDiscount = Math.min(100, Math.max(0, discountValue));
        
        setFormData(prev => {
            // Calculate new prices for all sizes when discount changes
            const newSizes = prev.sizes.map(size => ({
                ...size,
                price: newDiscount > 0 
                    ? Math.round(size.originalPrice * (1 - newDiscount/100))
                    : size.originalPrice
            }));
            
            return {
                ...prev,
                discount: newDiscount,
                sizes: newSizes,
                discountEndDate: newDiscount > 0 ? prev.discountEndDate : ""
            };
        });
    };
   
    const handleOriginalPriceChange = (sizeIndex, value) => {
        const priceValue = parseFloat(value) || 0;
        
        setFormData(prev => {
            const newSizes = [...prev.sizes];
            newSizes[sizeIndex] = {
                ...newSizes[sizeIndex],
                originalPrice: priceValue,
                price: prev.discount > 0 
                    ? Math.round(priceValue * (1 - prev.discount/100))
                    : priceValue
            };
            
            return { ...prev, sizes: newSizes };
        });
    };

    const handleDiscountEndDateChange = (e) => {
        setFormData(prev => ({
            ...prev,
            discountEndDate: e.target.value
        }));
    };


    
    const handleSubmit = async (e) => {
        e.preventDefault();
    
        const productData = new FormData();
        productData.append("name", formData.name);
        productData.append("material", formData.material);
        productData.append("category", formData.category);
        productData.append("description", formData.description);
        productData.append("discount", formData.discount);
        productData.append("discountEndDate", formData.discountEndDate);
    
        // Add size chart image if uploaded
        if (formData.sizeChartImage) {
            productData.append("sizeChartImage", formData.sizeChartImage);
        }
    
        // Create a deep copy of sizes with modified structure for saving
        const sizesForSaving = formData.sizes.map(size => ({
            size: size.size,
            Price: Number(size.originalPrice),
            DiscountedPrice: Number(size.price),  // This is the discounted price
            colors: size.colors.map(color => ({
                color: color.color,
                stock: Number(color.stock),
                image: null
            }))
        }));
        
        productData.append("sizes", JSON.stringify(sizesForSaving));
    
        // Append product images
        formData.images.forEach((image) => {
            if (image instanceof File) {
                productData.append("productImages", image);
            }
        });
    
        // Collect all color indexes in an array
        const colorIndexArray = [];
        
        // Append color images
        formData.sizes.forEach((size, sizeIndex) => {
            size.colors.forEach((color, colorIndex) => {
                if (color.image && color.image instanceof File) {
                    productData.append("colorImages", color.image);
                    colorIndexArray.push({sizeIndex, colorIndex});
                }
            });
        });
        
        // Append the colorIndexes array as a single JSON string
        if (colorIndexArray.length > 0) {
            productData.append("colorIndexes", JSON.stringify(colorIndexArray));
        }
    
        try {
            const res = await API.post("/product/add-product", productData, {
                headers: { "Content-Type": "multipart/form-data" }
            });
            console.log("Product Added:", res.data);
            alert("Product added successfully!");
            // Reset form
            setFormData({
                name: "",
                material: "",
                images: [],
                category: "Men",
                sizes: [{ size: "", price: 0, colors: [{ color: "", image: null, stock: 0 }] }],
                description: "",
                sizeChartImage: null
            });
        } catch (error) {
            console.error("Error Response:", error.response?.data);
            alert("Error adding product: " + (error.response?.data?.message || error.message));
        }
    };

  return (
    <div className="p-8 max-w-4xl mx-auto bg-white rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold mb-6 text-center text-gray-800 border-b-2 border-blue-500 pb-4">Add New Product</h2>
        
        <div className="bg-blue-50 p-6 rounded-lg mb-6 border border-blue-200">
            <h3 className="text-xl font-bold mb-4 text-blue-800">Basic Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label className="block text-sm font-bold text-gray-800 mb-1">Product Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        placeholder="Enter product name" 
                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition text-gray-900" 
                        value={formData.name} 
                        onChange={handleChange} 
                    />
                </div>
                <div>
                    <label className="block text-sm font-bold text-gray-800 mb-1">Material</label>
                    <input 
                        type="text" 
                        name="material" 
                        placeholder="Cotton, Silk, etc." 
                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition text-gray-900" 
                        value={formData.material} 
                        onChange={handleChange} 
                    />
                </div>
            </div>
            
            <div>
                <label className="block text-sm font-bold text-gray-800 mb-1">Category</label>
                <select 
                    name="category" 
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition text-gray-900" 
                    value={formData.category} 
                    onChange={handleChange}
                >
                    <option value="Men">Men</option>
                    <option value="Women">Women</option>
                    <option value="Kids">Kids</option>
                </select>
            </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg mb-6 border border-gray-200">
            <h3 className="text-xl font-bold mb-4 text-gray-800">Product Description</h3>
            
            <div className="mb-4">
                <label className="block text-sm font-bold text-gray-800 mb-1">Description</label>
                <textarea 
                    name="description" 
                    placeholder="Detailed product description" 
                    className="w-full p-3 border border-gray-300 rounded-md h-32 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition text-gray-900" 
                    value={formData.description} 
                    onChange={handleChange}
                ></textarea>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-200">
                <h3 className="text-xl font-bold mb-4 text-indigo-900">Product Images</h3>
                <div className="mb-3">
                    <label className="block text-sm font-bold text-gray-800 mb-1">
                        Upload Images (Max 4)
                    </label>
                    <input 
                        type="file" 
                        multiple 
                        accept="image/*" 
                        onChange={handleImageUpload} 
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-gray-900" 
                    />
                </div>

                <div className="flex gap-3 mt-3 flex-wrap">
                    {formData.images.length > 0 &&
                        formData.images.map((img, index) => (
                            <div key={index} className="relative group">
                                <img 
                                    src={URL.createObjectURL(img)} 
                                    alt="Preview" 
                                    className="w-24 h-24 object-cover border rounded-md shadow-sm" 
                                />
                                <button
                                    onClick={() => handleRemoveImage(index)}
                                    className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full text-xs opacity-0 group-hover:opacity-100 transition"
                                >
                                    ×
                                </button>
                            </div>
                        ))}
                </div>
            </div>
            
            <div className="bg-emerald-50 p-6 rounded-lg border border-emerald-200">
                <h3 className="text-xl font-bold mb-4 text-emerald-900">Size Chart</h3>
                <div className="mb-3">
                    <label className="block text-sm font-bold text-gray-800 mb-1">
                        Size Chart Image
                    </label>
                    <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleSizeChartUpload} 
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900" 
                    />
                </div>
                
                {formData.sizeChartImage && (
                    <div className="mt-3 relative group">
                        <img 
                            src={URL.createObjectURL(formData.sizeChartImage)} 
                            alt="Size Chart Preview" 
                            className="max-w-xs h-auto border rounded-md shadow-sm" 
                        />
                        <button
                            onClick={handleRemoveSizeChart}
                            className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full text-xs opacity-0 group-hover:opacity-100 transition"
                        >
                            ×
                        </button>
                    </div>
                )}
            </div>
        </div>

        <div className="bg-purple-50 p-6 rounded-lg mb-6 border border-purple-200">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-purple-900">Sizes & Colors</h3>
                <button 
                    className="bg-purple-700 hover:bg-purple-800 text-white py-2 px-4 rounded-md transition flex items-center gap-1 text-sm font-medium shadow-sm" 
                    onClick={handleAddSize}
                >
                    <span>+ Add Size</span>
                </button>
            </div>
            
            {formData.sizes.map((size, sizeIndex) => (
                <div key={sizeIndex} className="border border-purple-200 p-5 mb-4 rounded-lg bg-white shadow-sm">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label className="block text-sm font-bold mb-1 text-gray-800">Size</label>
                            <input 
                                type="text" 
                                placeholder="S, M, L, XL, etc." 
                                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-gray-900" 
                                value={size.size} 
                                onChange={(e) => handleSizeChange(sizeIndex, "size", e.target.value)} 
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold mb-1 text-gray-800">
                                Original Price
                            </label>
                            <input 
                                type="number" 
                                placeholder="Original Price" 
                                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-gray-900" 
                                value={size.originalPrice} 
                                onChange={(e) => handleOriginalPriceChange(sizeIndex, e.target.value)} 
                                min="0"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold mb-1 text-gray-800">
                                {formData.discount > 0 ? "Discounted Price" : "Price"}
                            </label>
                            <input 
                                type="number" 
                                className="w-full p-2 border border-gray-300 rounded-md bg-gray-100 text-gray-800 font-medium" 
                                value={size.price} 
                                readOnly
                            />
                        </div>
                    </div>

                    <div className="flex items-center mb-3">
                        <h4 className="text-sm font-bold text-gray-800">Color Variants</h4>
                        <button 
                            className="ml-auto bg-blue-600 hover:bg-blue-700 text-white py-1 px-3 rounded-md text-sm transition flex items-center gap-1 font-medium shadow-sm" 
                            onClick={() => handleAddColor(sizeIndex)}
                        >
                            <span>+ Add Color</span>
                        </button>
                    </div>

                    <div className="space-y-3">
                        {size.colors.map((color, colorIndex) => (
                            <div key={colorIndex} className="p-3 border border-gray-300 rounded-md bg-gray-50">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                    <div>
                                        <label className="block text-sm font-bold mb-1 text-gray-800">Color Name</label>
                                        <input 
                                            type="text" 
                                            placeholder="Red, Blue, Black, etc." 
                                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900" 
                                            value={color.color} 
                                            onChange={(e) => handleColorChange(sizeIndex, colorIndex, "color", e.target.value)} 
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-bold mb-1 text-gray-800">Stock</label>
                                        <input 
                                            type="number" 
                                            placeholder="Available quantity" 
                                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900" 
                                            value={color.stock} 
                                            onChange={(e) => handleColorChange(sizeIndex, colorIndex, "stock", e.target.value)} 
                                            min="0"
                                        />
                                    </div>
                                </div>
                                
                                <div className="flex items-start gap-4">
                                    <div className="flex-1">
                                        <label className="block text-sm font-bold mb-1 text-gray-800">Color Image</label>
                                        <input 
                                            type="file" 
                                            accept="image/*" 
                                            className="p-2 border border-gray-300 rounded-md w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900" 
                                            onChange={(e) => handleColorChange(sizeIndex, colorIndex, "image", e.target.files?.[0])} 
                                        />
                                    </div>
                                    
                                    {color.image && (
                                        <div className="mt-6 relative group">
                                            <img 
                                                src={URL.createObjectURL(color.image)} 
                                                alt="Color Preview" 
                                                className="w-16 h-16 object-cover border rounded-md shadow-sm" 
                                            />
                                            <button
                                                onClick={() => handleColorChange(sizeIndex, colorIndex, "image", null)}
                                                className="absolute top-0 right-0 bg-red-600 text-white p-1 rounded-full text-xs opacity-0 group-hover:opacity-100 transition"
                                            >
                                                ×
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>

        <div className="bg-amber-50 p-6 rounded-lg mb-6 border border-amber-200">
            <h3 className="text-xl font-bold mb-4 text-amber-900">Discount Settings</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-bold text-gray-800 mb-1">
                        Discount (%)
                    </label>
                    <input
                        type="number"
                        min="0"
                        max="100"
                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition text-gray-900"
                        value={formData.discount}
                        onChange={handleDiscountChange}
                        placeholder="0-100"
                    />
                </div>
                
                <div>
                    <label className="block text-sm font-bold text-gray-800 mb-1">
                        Discount Ends On
                    </label>
                    <input
                        type="date"
                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition disabled:bg-gray-100 disabled:opacity-70 text-gray-900"
                        value={formData.discountEndDate}
                        onChange={(e) => setFormData(prev => ({
                            ...prev,
                            discountEndDate: e.target.value
                        }))}
                        min={new Date().toISOString().split('T')[0]}
                        disabled={formData.discount <= 0}
                    />
                </div>
            </div>

            {/* Display Discount Preview */}
            {formData.discount > 0 && (
                <div className="mt-4 p-4 bg-white border border-amber-300 rounded-md shadow-sm">
                    <h4 className="font-bold text-amber-900 mb-2 flex items-center">
                        <span className="mr-2">⚡</span> Discount Preview
                    </h4>
                    <p className="text-sm bg-amber-200 inline-block px-3 py-1 rounded-full font-bold text-amber-900">
                        {formData.discount}% OFF
                        {formData.discountEndDate && (
                            <span> (Ends on {new Date(formData.discountEndDate).toLocaleDateString()})</span>
                        )}
                    </p>
                    {formData.sizes.length > 0 && (
                        <div className="mt-3 border-t border-amber-100 pt-3">
                            <p className="text-sm font-bold text-gray-800">Price adjustments:</p>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                                {formData.sizes.map((size, index) => (
                                    <div key={index} className="flex items-center text-sm bg-gray-50 p-2 rounded-md border border-gray-200">
                                        <span className="font-bold mr-2 text-gray-900">{size.size || 'Size ' + (index + 1)}:</span>
                                        <span className="text-gray-600 line-through mr-2">
                                            ₹{size.originalPrice}
                                        </span>
                                        <span className="text-green-700 font-bold">
                                            ₹{size.price}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>

        <button 
            onClick={handleSubmit} 
            className="w-full bg-blue-700 hover:bg-blue-800 text-white p-4 rounded-lg font-bold text-lg shadow-md transition-colors flex items-center justify-center gap-2"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
            </svg>
            Add Product
        </button>
    </div>
  );
};

export default AddProduct;