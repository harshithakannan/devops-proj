import React, { useState } from 'react';
import './index.css';

function App() {
  // Sample products data
  const products = [
    { id: 1, name: 'Tracks', category: 'Men', material: 'Nylon', price: 39.99 },
    { id: 2, name: 'T-shirt', category: 'Women', material: 'Cotton', price: 24.99, discount: 18 },
    { id: 3, name: 'Leggings', category: 'Women', material: 'Cotton', price: 34.99, discount: 20 },
    { id: 4, name: 'T-shirt', category: 'Kids', material: 'Cotton', price: 19.99 },
  ];
  
  // State for search and filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('default');
  
  // Categories for filtering
  const categories = ['All', 'Men', 'Women', 'Kids'];
  
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-3xl font-bold mb-6">Explore Our Collection</h1>
      <div className="relative mb-6">
        <input
          type="text"
          placeholder="Search our collection..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full py-2 px-4 pl-10 rounded-lg border border-gray-600 bg-gray-900 text-white focus:border-purple-500 focus:outline-none"
        />
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>
      
      {/* Category Filter Buttons */}
      <div className="flex flex-wrap gap-2 mb-6">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-md ${
              selectedCategory === category 
                ? 'bg-purple-700 text-white' 
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {category}
          </button>
        ))}
      </div>
      
      {/* Sort Dropdown */}
      <div className="relative w-full md:w-64 mb-6">
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="w-full py-2 px-4 rounded-lg appearance-none border border-gray-600 bg-gray-900 text-white pr-10 focus:border-purple-500 focus:outline-none"
        >
          <option value="default">Sort by</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
          <svg className="h-4 w-4 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
          </svg>
        </div>
      </div>
      
      {/* Product count */}
      <div className="text-sm text-gray-400 mb-6">
        4 products found
      </div>
      
      {/* The rest of your component would go here */}
    </div>
  );
}

export default App;