import { useState } from 'react';
import './App.css';

function ProductCard({ product, onWishlistToggle, wishlistedItems }) {
  const isWishlisted = wishlistedItems.includes(product.id);
  
  return (
    <div className="product-card">
      {product.discount && (
        <div className="discount-tag">{product.discount}% OFF</div>
      )}
      <button 
        className={`wishlist-button ${isWishlisted ? 'active' : ''}`}
        onClick={() => onWishlistToggle(product.id)}
        aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
      >
        <svg viewBox="0 0 24 24">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
        </svg>
      </button>
      <img src={product.image} alt={product.title} className="product-image" />
      <div className="p-4">
        <h3 className="product-title">{product.title}</h3>
        <p className="product-category">{product.category}</p>
        <div className="flex items-center mt-2">
          <span className="product-price">₹{product.price}</span>
          {product.originalPrice && (
            <span className="original-price ml-2">₹{product.originalPrice}</span>
          )}
        </div>
      </div>
    </div>
  );
}

function ProductListing() {
  const [wishlistedItems, setWishlistedItems] = useState([]);
  const [activeCategory, setActiveCategory] = useState('All');
  
  // Sample product data matching your screenshot
  const products = [
    {
      id: 1,
      title: 'T shirt',
      category: 'Cotton',
      price: 205,
      originalPrice: 250,
      discount: 18,
      image: '/path-to-tshirt-image-1.jpg'
    },
    {
      id: 2,
      title: 'T-shirt',
      category: 'Cotton',
      price: 430,
      image: '/path-to-tshirt-image-2.jpg'
    },
    {
      id: 3,
      title: 'Tracks',
      category: 'Nylon',
      price: 360,
      image: '/path-to-tracks-image.jpg'
    },
    {
      id: 4,
      title: 'Leggins',
      category: 'Cotton',
      price: 400,
      originalPrice: 500,
      discount: 20,
      image: '/path-to-leggins-image.jpg'
    }
  ];

  const handleWishlistToggle = (productId) => {
    setWishlistedItems(prev => {
      if (prev.includes(productId)) {
        return prev.filter(id => id !== productId);
      } else {
        return [...prev, productId];
      }
    });
  };

  const filteredProducts = activeCategory === 'All' 
    ? products 
    : products.filter(product => product.category.includes(activeCategory));

  const categories = ['All', 'Men', 'Women', 'Kids'];
  
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search products..."
            className="w-full p-3 rounded-lg bg-white text-black placeholder-gray-600 border border-gray-300 focus:border-purple-500 focus:outline-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          <button className="flex items-center bg-white text-black px-4 py-2 rounded-lg border border-gray-300">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            Filters
          </button>
          
          {categories.map(category => (
            <button
              key={category}
              className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                activeCategory === category 
                  ? 'bg-purple-800 text-white' 
                  : 'bg-white text-black border border-gray-300'
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        
        <p className="text-black mb-4">{filteredProducts.length} products found</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 products-grid">
        {filteredProducts.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onWishlistToggle={handleWishlistToggle}
            wishlistedItems={wishlistedItems}
          />
        ))}
      </div>
    </div>
  );
}

export default ProductListing;