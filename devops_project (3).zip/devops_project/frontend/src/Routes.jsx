import { BrowserRouter , Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import AdminDashboard from "./pages/AdminDashboard";
import AddProduct from "./pages/AddProduct";
import ProductCard from "./pages/ViewProductByAdmin";
import ProductListing from "./pages/ViewProductByCustomer";
import EditProduct from "./pages/EditProduct";
import ReportButton from "./pages/ReportButton";
const AppRoutes = () => {
  return (
   <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/admin-dashboard" element={<AdminDashboard/>} />
      <Route path="/add-product" element={<AddProduct/>} />
      <Route path="/all-product" element={<ProductCard/>} />
      <Route path="/view-product" element={<ProductListing/>} />
      <Route path="/edit-product/:productId" element={<EditProduct/>} />
      <Route path="/generate-stock-report" element={<ReportButton/>} />  
    </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
